/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 20, 2018 2:47:55 PM                     ---
 * ----------------------------------------------------------------
 */
package com.icommerce.core.jalo;

import com.icommerce.core.constants.IcommerceCoreConstants;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.user.Address;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link com.icommerce.core.jalo.CustomerRegistrationAddress CustomerRegistrationAddress}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedCustomerRegistrationAddress extends Address
{
	/** Qualifier of the <code>CustomerRegistrationAddress.organizationName</code> attribute **/
	public static final String ORGANIZATIONNAME = "organizationName";
	/** Qualifier of the <code>CustomerRegistrationAddress.state</code> attribute **/
	public static final String STATE = "state";
	/** Qualifier of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute **/
	public static final String ISSAMEASSHIPPINGADDRESS = "isSameAsShippingAddress";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(Address.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(ORGANIZATIONNAME, AttributeMode.INITIAL);
		tmp.put(STATE, AttributeMode.INITIAL);
		tmp.put(ISSAMEASSHIPPINGADDRESS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute.
	 * @return the isSameAsShippingAddress
	 */
	public Boolean isIsSameAsShippingAddress(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, ISSAMEASSHIPPINGADDRESS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute.
	 * @return the isSameAsShippingAddress
	 */
	public Boolean isIsSameAsShippingAddress()
	{
		return isIsSameAsShippingAddress( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute. 
	 * @return the isSameAsShippingAddress
	 */
	public boolean isIsSameAsShippingAddressAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isIsSameAsShippingAddress( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute. 
	 * @return the isSameAsShippingAddress
	 */
	public boolean isIsSameAsShippingAddressAsPrimitive()
	{
		return isIsSameAsShippingAddressAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute. 
	 * @param value the isSameAsShippingAddress
	 */
	public void setIsSameAsShippingAddress(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, ISSAMEASSHIPPINGADDRESS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute. 
	 * @param value the isSameAsShippingAddress
	 */
	public void setIsSameAsShippingAddress(final Boolean value)
	{
		setIsSameAsShippingAddress( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute. 
	 * @param value the isSameAsShippingAddress
	 */
	public void setIsSameAsShippingAddress(final SessionContext ctx, final boolean value)
	{
		setIsSameAsShippingAddress( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.isSameAsShippingAddress</code> attribute. 
	 * @param value the isSameAsShippingAddress
	 */
	public void setIsSameAsShippingAddress(final boolean value)
	{
		setIsSameAsShippingAddress( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.organizationName</code> attribute.
	 * @return the organizationName
	 */
	public String getOrganizationName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ORGANIZATIONNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.organizationName</code> attribute.
	 * @return the organizationName
	 */
	public String getOrganizationName()
	{
		return getOrganizationName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.organizationName</code> attribute. 
	 * @param value the organizationName
	 */
	public void setOrganizationName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ORGANIZATIONNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.organizationName</code> attribute. 
	 * @param value the organizationName
	 */
	public void setOrganizationName(final String value)
	{
		setOrganizationName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.state</code> attribute.
	 * @return the state
	 */
	public String getState(final SessionContext ctx)
	{
		return (String)getProperty( ctx, STATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationAddress.state</code> attribute.
	 * @return the state
	 */
	public String getState()
	{
		return getState( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.state</code> attribute. 
	 * @param value the state
	 */
	public void setState(final SessionContext ctx, final String value)
	{
		setProperty(ctx, STATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationAddress.state</code> attribute. 
	 * @param value the state
	 */
	public void setState(final String value)
	{
		setState( getSession().getSessionContext(), value );
	}
	
}
