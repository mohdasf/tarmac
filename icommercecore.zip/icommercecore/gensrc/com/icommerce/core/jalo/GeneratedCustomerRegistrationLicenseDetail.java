/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 20, 2018 2:47:55 PM                     ---
 * ----------------------------------------------------------------
 */
package com.icommerce.core.jalo;

import com.icommerce.core.constants.IcommerceCoreConstants;
import com.icommerce.core.jalo.CustomerRegistrationAddress;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link com.icommerce.core.jalo.CustomerRegistrationLicenseDetail CustomerRegistrationLicenseDetail}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedCustomerRegistrationLicenseDetail extends GenericItem
{
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute **/
	public static final String ISFEDERALORGANIZATION = "isFederalOrganization";
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.licenceName</code> attribute **/
	public static final String LICENCENAME = "licenceName";
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.licenceStateNumber</code> attribute **/
	public static final String LICENCESTATENUMBER = "licenceStateNumber";
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.licenceExpiryDate</code> attribute **/
	public static final String LICENCEEXPIRYDATE = "licenceExpiryDate";
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.licenceAddressLine1</code> attribute **/
	public static final String LICENCEADDRESSLINE1 = "licenceAddressLine1";
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.stateIssuingLicence</code> attribute **/
	public static final String STATEISSUINGLICENCE = "stateIssuingLicence";
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.customerRegistrationShippingAddress</code> attribute **/
	public static final String CUSTOMERREGISTRATIONSHIPPINGADDRESS = "customerRegistrationShippingAddress";
	/** Qualifier of the <code>CustomerRegistrationLicenseDetail.hoursOfOperation</code> attribute **/
	public static final String HOURSOFOPERATION = "hoursOfOperation";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(ISFEDERALORGANIZATION, AttributeMode.INITIAL);
		tmp.put(LICENCENAME, AttributeMode.INITIAL);
		tmp.put(LICENCESTATENUMBER, AttributeMode.INITIAL);
		tmp.put(LICENCEEXPIRYDATE, AttributeMode.INITIAL);
		tmp.put(LICENCEADDRESSLINE1, AttributeMode.INITIAL);
		tmp.put(STATEISSUINGLICENCE, AttributeMode.INITIAL);
		tmp.put(CUSTOMERREGISTRATIONSHIPPINGADDRESS, AttributeMode.INITIAL);
		tmp.put(HOURSOFOPERATION, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.customerRegistrationShippingAddress</code> attribute.
	 * @return the customerRegistrationShippingAddress
	 */
	public CustomerRegistrationAddress getCustomerRegistrationShippingAddress(final SessionContext ctx)
	{
		return (CustomerRegistrationAddress)getProperty( ctx, CUSTOMERREGISTRATIONSHIPPINGADDRESS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.customerRegistrationShippingAddress</code> attribute.
	 * @return the customerRegistrationShippingAddress
	 */
	public CustomerRegistrationAddress getCustomerRegistrationShippingAddress()
	{
		return getCustomerRegistrationShippingAddress( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.customerRegistrationShippingAddress</code> attribute. 
	 * @param value the customerRegistrationShippingAddress
	 */
	public void setCustomerRegistrationShippingAddress(final SessionContext ctx, final CustomerRegistrationAddress value)
	{
		setProperty(ctx, CUSTOMERREGISTRATIONSHIPPINGADDRESS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.customerRegistrationShippingAddress</code> attribute. 
	 * @param value the customerRegistrationShippingAddress
	 */
	public void setCustomerRegistrationShippingAddress(final CustomerRegistrationAddress value)
	{
		setCustomerRegistrationShippingAddress( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.hoursOfOperation</code> attribute.
	 * @return the hoursOfOperation - hours Of Operation
	 */
	public String getHoursOfOperation(final SessionContext ctx)
	{
		return (String)getProperty( ctx, HOURSOFOPERATION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.hoursOfOperation</code> attribute.
	 * @return the hoursOfOperation - hours Of Operation
	 */
	public String getHoursOfOperation()
	{
		return getHoursOfOperation( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.hoursOfOperation</code> attribute. 
	 * @param value the hoursOfOperation - hours Of Operation
	 */
	public void setHoursOfOperation(final SessionContext ctx, final String value)
	{
		setProperty(ctx, HOURSOFOPERATION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.hoursOfOperation</code> attribute. 
	 * @param value the hoursOfOperation - hours Of Operation
	 */
	public void setHoursOfOperation(final String value)
	{
		setHoursOfOperation( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute.
	 * @return the isFederalOrganization
	 */
	public Boolean isIsFederalOrganization(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, ISFEDERALORGANIZATION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute.
	 * @return the isFederalOrganization
	 */
	public Boolean isIsFederalOrganization()
	{
		return isIsFederalOrganization( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute. 
	 * @return the isFederalOrganization
	 */
	public boolean isIsFederalOrganizationAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isIsFederalOrganization( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute. 
	 * @return the isFederalOrganization
	 */
	public boolean isIsFederalOrganizationAsPrimitive()
	{
		return isIsFederalOrganizationAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute. 
	 * @param value the isFederalOrganization
	 */
	public void setIsFederalOrganization(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, ISFEDERALORGANIZATION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute. 
	 * @param value the isFederalOrganization
	 */
	public void setIsFederalOrganization(final Boolean value)
	{
		setIsFederalOrganization( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute. 
	 * @param value the isFederalOrganization
	 */
	public void setIsFederalOrganization(final SessionContext ctx, final boolean value)
	{
		setIsFederalOrganization( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.isFederalOrganization</code> attribute. 
	 * @param value the isFederalOrganization
	 */
	public void setIsFederalOrganization(final boolean value)
	{
		setIsFederalOrganization( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceAddressLine1</code> attribute.
	 * @return the licenceAddressLine1
	 */
	public String getLicenceAddressLine1(final SessionContext ctx)
	{
		return (String)getProperty( ctx, LICENCEADDRESSLINE1);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceAddressLine1</code> attribute.
	 * @return the licenceAddressLine1
	 */
	public String getLicenceAddressLine1()
	{
		return getLicenceAddressLine1( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceAddressLine1</code> attribute. 
	 * @param value the licenceAddressLine1
	 */
	public void setLicenceAddressLine1(final SessionContext ctx, final String value)
	{
		setProperty(ctx, LICENCEADDRESSLINE1,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceAddressLine1</code> attribute. 
	 * @param value the licenceAddressLine1
	 */
	public void setLicenceAddressLine1(final String value)
	{
		setLicenceAddressLine1( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceExpiryDate</code> attribute.
	 * @return the licenceExpiryDate
	 */
	public Date getLicenceExpiryDate(final SessionContext ctx)
	{
		return (Date)getProperty( ctx, LICENCEEXPIRYDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceExpiryDate</code> attribute.
	 * @return the licenceExpiryDate
	 */
	public Date getLicenceExpiryDate()
	{
		return getLicenceExpiryDate( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceExpiryDate</code> attribute. 
	 * @param value the licenceExpiryDate
	 */
	public void setLicenceExpiryDate(final SessionContext ctx, final Date value)
	{
		setProperty(ctx, LICENCEEXPIRYDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceExpiryDate</code> attribute. 
	 * @param value the licenceExpiryDate
	 */
	public void setLicenceExpiryDate(final Date value)
	{
		setLicenceExpiryDate( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceName</code> attribute.
	 * @return the licenceName
	 */
	public String getLicenceName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, LICENCENAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceName</code> attribute.
	 * @return the licenceName
	 */
	public String getLicenceName()
	{
		return getLicenceName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceName</code> attribute. 
	 * @param value the licenceName
	 */
	public void setLicenceName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, LICENCENAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceName</code> attribute. 
	 * @param value the licenceName
	 */
	public void setLicenceName(final String value)
	{
		setLicenceName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceStateNumber</code> attribute.
	 * @return the licenceStateNumber
	 */
	public String getLicenceStateNumber(final SessionContext ctx)
	{
		return (String)getProperty( ctx, LICENCESTATENUMBER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.licenceStateNumber</code> attribute.
	 * @return the licenceStateNumber
	 */
	public String getLicenceStateNumber()
	{
		return getLicenceStateNumber( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceStateNumber</code> attribute. 
	 * @param value the licenceStateNumber
	 */
	public void setLicenceStateNumber(final SessionContext ctx, final String value)
	{
		setProperty(ctx, LICENCESTATENUMBER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.licenceStateNumber</code> attribute. 
	 * @param value the licenceStateNumber
	 */
	public void setLicenceStateNumber(final String value)
	{
		setLicenceStateNumber( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.stateIssuingLicence</code> attribute.
	 * @return the stateIssuingLicence
	 */
	public String getStateIssuingLicence(final SessionContext ctx)
	{
		return (String)getProperty( ctx, STATEISSUINGLICENCE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>CustomerRegistrationLicenseDetail.stateIssuingLicence</code> attribute.
	 * @return the stateIssuingLicence
	 */
	public String getStateIssuingLicence()
	{
		return getStateIssuingLicence( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.stateIssuingLicence</code> attribute. 
	 * @param value the stateIssuingLicence
	 */
	public void setStateIssuingLicence(final SessionContext ctx, final String value)
	{
		setProperty(ctx, STATEISSUINGLICENCE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>CustomerRegistrationLicenseDetail.stateIssuingLicence</code> attribute. 
	 * @param value the stateIssuingLicence
	 */
	public void setStateIssuingLicence(final String value)
	{
		setStateIssuingLicence( getSession().getSessionContext(), value );
	}
	
}
