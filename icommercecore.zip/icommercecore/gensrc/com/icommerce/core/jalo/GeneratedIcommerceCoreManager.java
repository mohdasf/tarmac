/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 20, 2018 2:47:55 PM                     ---
 * ----------------------------------------------------------------
 */
package com.icommerce.core.jalo;

import com.icommerce.core.constants.IcommerceCoreConstants;
import com.icommerce.core.jalo.ApparelProduct;
import com.icommerce.core.jalo.ApparelSizeVariantProduct;
import com.icommerce.core.jalo.ApparelStyleVariantProduct;
import com.icommerce.core.jalo.CustomerRegistrationAddress;
import com.icommerce.core.jalo.CustomerRegistrationLicenseDetail;
import com.icommerce.core.jalo.ElectronicsColorVariantProduct;
import com.icommerce.core.jalo.IcommerceCustomerRegistration;
import com.icommerceb2b.core.jalo.IcommerceCustomerRegEmailProcess;
import de.hybris.platform.b2b.jalo.B2BCustomer;
import de.hybris.platform.b2b.jalo.B2BUnit;
import de.hybris.platform.commerceservices.jalo.OrgUnit;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import de.hybris.platform.jalo.user.Address;
import de.hybris.platform.jalo.user.Customer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Generated class for type <code>IcommerceCoreManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedIcommerceCoreManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("name1", AttributeMode.INITIAL);
		tmp.put("name2", AttributeMode.INITIAL);
		tmp.put("paymentTerms", AttributeMode.INITIAL);
		tmp.put("orderBlocked", AttributeMode.INITIAL);
		tmp.put("deliveryBlocked", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.b2b.jalo.B2BUnit", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("jobTitle", AttributeMode.INITIAL);
		tmp.put("firstName", AttributeMode.INITIAL);
		tmp.put("lastname", AttributeMode.INITIAL);
		tmp.put("phone", AttributeMode.INITIAL);
		tmp.put("department", AttributeMode.INITIAL);
		tmp.put("isNotified", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.b2b.jalo.B2BCustomer", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("sapCustomerType", AttributeMode.INITIAL);
		tmp.put("addressId", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.user.Address", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Address.addressId</code> attribute.
	 * @return the addressId - addressId field of Customer's Address
	 */
	public String getAddressId(final SessionContext ctx, final Address item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.Address.ADDRESSID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Address.addressId</code> attribute.
	 * @return the addressId - addressId field of Customer's Address
	 */
	public String getAddressId(final Address item)
	{
		return getAddressId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Address.addressId</code> attribute. 
	 * @param value the addressId - addressId field of Customer's Address
	 */
	public void setAddressId(final SessionContext ctx, final Address item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.Address.ADDRESSID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Address.addressId</code> attribute. 
	 * @param value the addressId - addressId field of Customer's Address
	 */
	public void setAddressId(final Address item, final String value)
	{
		setAddressId( getSession().getSessionContext(), item, value );
	}
	
	public ApparelProduct createApparelProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.APPARELPRODUCT );
			return (ApparelProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelProduct createApparelProduct(final Map attributeValues)
	{
		return createApparelProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.APPARELSIZEVARIANTPRODUCT );
			return (ApparelSizeVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelSizeVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final Map attributeValues)
	{
		return createApparelSizeVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.APPARELSTYLEVARIANTPRODUCT );
			return (ApparelStyleVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelStyleVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final Map attributeValues)
	{
		return createApparelStyleVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public CustomerRegistrationAddress createCustomerRegistrationAddress(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.CUSTOMERREGISTRATIONADDRESS );
			return (CustomerRegistrationAddress)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating CustomerRegistrationAddress : "+e.getMessage(), 0 );
		}
	}
	
	public CustomerRegistrationAddress createCustomerRegistrationAddress(final Map attributeValues)
	{
		return createCustomerRegistrationAddress( getSession().getSessionContext(), attributeValues );
	}
	
	public CustomerRegistrationLicenseDetail createCustomerRegistrationLicenseDetail(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.CUSTOMERREGISTRATIONLICENSEDETAIL );
			return (CustomerRegistrationLicenseDetail)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating CustomerRegistrationLicenseDetail : "+e.getMessage(), 0 );
		}
	}
	
	public CustomerRegistrationLicenseDetail createCustomerRegistrationLicenseDetail(final Map attributeValues)
	{
		return createCustomerRegistrationLicenseDetail( getSession().getSessionContext(), attributeValues );
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.ELECTRONICSCOLORVARIANTPRODUCT );
			return (ElectronicsColorVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ElectronicsColorVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final Map attributeValues)
	{
		return createElectronicsColorVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public IcommerceCustomerRegEmailProcess createIcommerceCustomerRegEmailProcess(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.ICOMMERCECUSTOMERREGEMAILPROCESS );
			return (IcommerceCustomerRegEmailProcess)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating IcommerceCustomerRegEmailProcess : "+e.getMessage(), 0 );
		}
	}
	
	public IcommerceCustomerRegEmailProcess createIcommerceCustomerRegEmailProcess(final Map attributeValues)
	{
		return createIcommerceCustomerRegEmailProcess( getSession().getSessionContext(), attributeValues );
	}
	
	public IcommerceCustomerRegistration createIcommerceCustomerRegistration(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( IcommerceCoreConstants.TC.ICOMMERCECUSTOMERREGISTRATION );
			return (IcommerceCustomerRegistration)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating IcommerceCustomerRegistration : "+e.getMessage(), 0 );
		}
	}
	
	public IcommerceCustomerRegistration createIcommerceCustomerRegistration(final Map attributeValues)
	{
		return createIcommerceCustomerRegistration( getSession().getSessionContext(), attributeValues );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.deliveryBlocked</code> attribute.
	 * @return the deliveryBlocked
	 */
	public Boolean isDeliveryBlocked(final SessionContext ctx, final B2BUnit item)
	{
		return (Boolean)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BUnit.DELIVERYBLOCKED);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.deliveryBlocked</code> attribute.
	 * @return the deliveryBlocked
	 */
	public Boolean isDeliveryBlocked(final B2BUnit item)
	{
		return isDeliveryBlocked( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.deliveryBlocked</code> attribute. 
	 * @return the deliveryBlocked
	 */
	public boolean isDeliveryBlockedAsPrimitive(final SessionContext ctx, final B2BUnit item)
	{
		Boolean value = isDeliveryBlocked( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.deliveryBlocked</code> attribute. 
	 * @return the deliveryBlocked
	 */
	public boolean isDeliveryBlockedAsPrimitive(final B2BUnit item)
	{
		return isDeliveryBlockedAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.deliveryBlocked</code> attribute. 
	 * @param value the deliveryBlocked
	 */
	public void setDeliveryBlocked(final SessionContext ctx, final B2BUnit item, final Boolean value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BUnit.DELIVERYBLOCKED,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.deliveryBlocked</code> attribute. 
	 * @param value the deliveryBlocked
	 */
	public void setDeliveryBlocked(final B2BUnit item, final Boolean value)
	{
		setDeliveryBlocked( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.deliveryBlocked</code> attribute. 
	 * @param value the deliveryBlocked
	 */
	public void setDeliveryBlocked(final SessionContext ctx, final B2BUnit item, final boolean value)
	{
		setDeliveryBlocked( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.deliveryBlocked</code> attribute. 
	 * @param value the deliveryBlocked
	 */
	public void setDeliveryBlocked(final B2BUnit item, final boolean value)
	{
		setDeliveryBlocked( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.department</code> attribute.
	 * @return the department - Last Name of the B2b Customer
	 */
	public String getDepartment(final SessionContext ctx, final B2BCustomer item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BCustomer.DEPARTMENT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.department</code> attribute.
	 * @return the department - Last Name of the B2b Customer
	 */
	public String getDepartment(final B2BCustomer item)
	{
		return getDepartment( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.department</code> attribute. 
	 * @param value the department - Last Name of the B2b Customer
	 */
	public void setDepartment(final SessionContext ctx, final B2BCustomer item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BCustomer.DEPARTMENT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.department</code> attribute. 
	 * @param value the department - Last Name of the B2b Customer
	 */
	public void setDepartment(final B2BCustomer item, final String value)
	{
		setDepartment( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.firstName</code> attribute.
	 * @return the firstName - First Name of the B2b Customer
	 */
	public String getFirstName(final SessionContext ctx, final B2BCustomer item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BCustomer.FIRSTNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.firstName</code> attribute.
	 * @return the firstName - First Name of the B2b Customer
	 */
	public String getFirstName(final B2BCustomer item)
	{
		return getFirstName( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.firstName</code> attribute. 
	 * @param value the firstName - First Name of the B2b Customer
	 */
	public void setFirstName(final SessionContext ctx, final B2BCustomer item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BCustomer.FIRSTNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.firstName</code> attribute. 
	 * @param value the firstName - First Name of the B2b Customer
	 */
	public void setFirstName(final B2BCustomer item, final String value)
	{
		setFirstName( getSession().getSessionContext(), item, value );
	}
	
	@Override
	public String getName()
	{
		return IcommerceCoreConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.isNotified</code> attribute.
	 * @return the isNotified - Indicates if the customer has been notified by email
	 */
	public Boolean isIsNotified(final SessionContext ctx, final B2BCustomer item)
	{
		return (Boolean)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BCustomer.ISNOTIFIED);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.isNotified</code> attribute.
	 * @return the isNotified - Indicates if the customer has been notified by email
	 */
	public Boolean isIsNotified(final B2BCustomer item)
	{
		return isIsNotified( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.isNotified</code> attribute. 
	 * @return the isNotified - Indicates if the customer has been notified by email
	 */
	public boolean isIsNotifiedAsPrimitive(final SessionContext ctx, final B2BCustomer item)
	{
		Boolean value = isIsNotified( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.isNotified</code> attribute. 
	 * @return the isNotified - Indicates if the customer has been notified by email
	 */
	public boolean isIsNotifiedAsPrimitive(final B2BCustomer item)
	{
		return isIsNotifiedAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.isNotified</code> attribute. 
	 * @param value the isNotified - Indicates if the customer has been notified by email
	 */
	public void setIsNotified(final SessionContext ctx, final B2BCustomer item, final Boolean value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BCustomer.ISNOTIFIED,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.isNotified</code> attribute. 
	 * @param value the isNotified - Indicates if the customer has been notified by email
	 */
	public void setIsNotified(final B2BCustomer item, final Boolean value)
	{
		setIsNotified( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.isNotified</code> attribute. 
	 * @param value the isNotified - Indicates if the customer has been notified by email
	 */
	public void setIsNotified(final SessionContext ctx, final B2BCustomer item, final boolean value)
	{
		setIsNotified( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.isNotified</code> attribute. 
	 * @param value the isNotified - Indicates if the customer has been notified by email
	 */
	public void setIsNotified(final B2BCustomer item, final boolean value)
	{
		setIsNotified( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.jobTitle</code> attribute.
	 * @return the jobTitle - JobTitle of the B2b Customer
	 */
	public String getJobTitle(final SessionContext ctx, final B2BCustomer item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BCustomer.JOBTITLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.jobTitle</code> attribute.
	 * @return the jobTitle - JobTitle of the B2b Customer
	 */
	public String getJobTitle(final B2BCustomer item)
	{
		return getJobTitle( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.jobTitle</code> attribute. 
	 * @param value the jobTitle - JobTitle of the B2b Customer
	 */
	public void setJobTitle(final SessionContext ctx, final B2BCustomer item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BCustomer.JOBTITLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.jobTitle</code> attribute. 
	 * @param value the jobTitle - JobTitle of the B2b Customer
	 */
	public void setJobTitle(final B2BCustomer item, final String value)
	{
		setJobTitle( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.lastname</code> attribute.
	 * @return the lastname - Last Name of the B2b Customer
	 */
	public String getLastname(final SessionContext ctx, final B2BCustomer item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BCustomer.LASTNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.lastname</code> attribute.
	 * @return the lastname - Last Name of the B2b Customer
	 */
	public String getLastname(final B2BCustomer item)
	{
		return getLastname( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.lastname</code> attribute. 
	 * @param value the lastname - Last Name of the B2b Customer
	 */
	public void setLastname(final SessionContext ctx, final B2BCustomer item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BCustomer.LASTNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.lastname</code> attribute. 
	 * @param value the lastname - Last Name of the B2b Customer
	 */
	public void setLastname(final B2BCustomer item, final String value)
	{
		setLastname( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.name1</code> attribute.
	 * @return the name1
	 */
	public String getName1(final SessionContext ctx, final B2BUnit item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BUnit.NAME1);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.name1</code> attribute.
	 * @return the name1
	 */
	public String getName1(final B2BUnit item)
	{
		return getName1( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.name1</code> attribute. 
	 * @param value the name1
	 */
	public void setName1(final SessionContext ctx, final B2BUnit item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BUnit.NAME1,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.name1</code> attribute. 
	 * @param value the name1
	 */
	public void setName1(final B2BUnit item, final String value)
	{
		setName1( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.name2</code> attribute.
	 * @return the name2
	 */
	public String getName2(final SessionContext ctx, final B2BUnit item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BUnit.NAME2);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.name2</code> attribute.
	 * @return the name2
	 */
	public String getName2(final B2BUnit item)
	{
		return getName2( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.name2</code> attribute. 
	 * @param value the name2
	 */
	public void setName2(final SessionContext ctx, final B2BUnit item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BUnit.NAME2,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.name2</code> attribute. 
	 * @param value the name2
	 */
	public void setName2(final B2BUnit item, final String value)
	{
		setName2( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.orderBlocked</code> attribute.
	 * @return the orderBlocked
	 */
	public Boolean isOrderBlocked(final SessionContext ctx, final B2BUnit item)
	{
		return (Boolean)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BUnit.ORDERBLOCKED);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.orderBlocked</code> attribute.
	 * @return the orderBlocked
	 */
	public Boolean isOrderBlocked(final B2BUnit item)
	{
		return isOrderBlocked( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.orderBlocked</code> attribute. 
	 * @return the orderBlocked
	 */
	public boolean isOrderBlockedAsPrimitive(final SessionContext ctx, final B2BUnit item)
	{
		Boolean value = isOrderBlocked( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.orderBlocked</code> attribute. 
	 * @return the orderBlocked
	 */
	public boolean isOrderBlockedAsPrimitive(final B2BUnit item)
	{
		return isOrderBlockedAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.orderBlocked</code> attribute. 
	 * @param value the orderBlocked
	 */
	public void setOrderBlocked(final SessionContext ctx, final B2BUnit item, final Boolean value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BUnit.ORDERBLOCKED,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.orderBlocked</code> attribute. 
	 * @param value the orderBlocked
	 */
	public void setOrderBlocked(final B2BUnit item, final Boolean value)
	{
		setOrderBlocked( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.orderBlocked</code> attribute. 
	 * @param value the orderBlocked
	 */
	public void setOrderBlocked(final SessionContext ctx, final B2BUnit item, final boolean value)
	{
		setOrderBlocked( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.orderBlocked</code> attribute. 
	 * @param value the orderBlocked
	 */
	public void setOrderBlocked(final B2BUnit item, final boolean value)
	{
		setOrderBlocked( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.paymentTerms</code> attribute.
	 * @return the paymentTerms
	 */
	public String getPaymentTerms(final SessionContext ctx, final B2BUnit item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BUnit.PAYMENTTERMS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BUnit.paymentTerms</code> attribute.
	 * @return the paymentTerms
	 */
	public String getPaymentTerms(final B2BUnit item)
	{
		return getPaymentTerms( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.paymentTerms</code> attribute. 
	 * @param value the paymentTerms
	 */
	public void setPaymentTerms(final SessionContext ctx, final B2BUnit item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BUnit.PAYMENTTERMS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BUnit.paymentTerms</code> attribute. 
	 * @param value the paymentTerms
	 */
	public void setPaymentTerms(final B2BUnit item, final String value)
	{
		setPaymentTerms( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.phone</code> attribute.
	 * @return the phone - Last Name of the B2b Customer
	 */
	public String getPhone(final SessionContext ctx, final B2BCustomer item)
	{
		return (String)item.getProperty( ctx, IcommerceCoreConstants.Attributes.B2BCustomer.PHONE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>B2BCustomer.phone</code> attribute.
	 * @return the phone - Last Name of the B2b Customer
	 */
	public String getPhone(final B2BCustomer item)
	{
		return getPhone( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.phone</code> attribute. 
	 * @param value the phone - Last Name of the B2b Customer
	 */
	public void setPhone(final SessionContext ctx, final B2BCustomer item, final String value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.B2BCustomer.PHONE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>B2BCustomer.phone</code> attribute. 
	 * @param value the phone - Last Name of the B2b Customer
	 */
	public void setPhone(final B2BCustomer item, final String value)
	{
		setPhone( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Address.sapCustomerType</code> attribute.
	 * @return the sapCustomerType - collection set ST/BP/SH etc.
	 */
	public Set<String> getSapCustomerType(final SessionContext ctx, final Address item)
	{
		Set<String> coll = (Set<String>)item.getProperty( ctx, IcommerceCoreConstants.Attributes.Address.SAPCUSTOMERTYPE);
		return coll != null ? coll : Collections.EMPTY_SET;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Address.sapCustomerType</code> attribute.
	 * @return the sapCustomerType - collection set ST/BP/SH etc.
	 */
	public Set<String> getSapCustomerType(final Address item)
	{
		return getSapCustomerType( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Address.sapCustomerType</code> attribute. 
	 * @param value the sapCustomerType - collection set ST/BP/SH etc.
	 */
	public void setSapCustomerType(final SessionContext ctx, final Address item, final Set<String> value)
	{
		item.setProperty(ctx, IcommerceCoreConstants.Attributes.Address.SAPCUSTOMERTYPE,value == null || !value.isEmpty() ? value : null );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Address.sapCustomerType</code> attribute. 
	 * @param value the sapCustomerType - collection set ST/BP/SH etc.
	 */
	public void setSapCustomerType(final Address item, final Set<String> value)
	{
		setSapCustomerType( getSession().getSessionContext(), item, value );
	}
	
}
