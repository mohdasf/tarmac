/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 20, 2018 2:47:55 PM                     ---
 * ----------------------------------------------------------------
 */
package com.icommerce.core.jalo;

import com.icommerce.core.constants.IcommerceCoreConstants;
import com.icommerce.core.jalo.CustomerRegistrationAddress;
import com.icommerce.core.jalo.CustomerRegistrationLicenseDetail;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link com.icommerce.core.jalo.IcommerceCustomerRegistration IcommerceCustomerRegistration}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedIcommerceCustomerRegistration extends GenericItem
{
	/** Qualifier of the <code>IcommerceCustomerRegistration.firstName</code> attribute **/
	public static final String FIRSTNAME = "firstName";
	/** Qualifier of the <code>IcommerceCustomerRegistration.lastName</code> attribute **/
	public static final String LASTNAME = "lastName";
	/** Qualifier of the <code>IcommerceCustomerRegistration.position</code> attribute **/
	public static final String POSITION = "position";
	/** Qualifier of the <code>IcommerceCustomerRegistration.role</code> attribute **/
	public static final String ROLE = "role";
	/** Qualifier of the <code>IcommerceCustomerRegistration.organizationName</code> attribute **/
	public static final String ORGANIZATIONNAME = "organizationName";
	/** Qualifier of the <code>IcommerceCustomerRegistration.emailId</code> attribute **/
	public static final String EMAILID = "emailId";
	/** Qualifier of the <code>IcommerceCustomerRegistration.optNotify</code> attribute **/
	public static final String OPTNOTIFY = "optNotify";
	/** Qualifier of the <code>IcommerceCustomerRegistration.customerRegistrationLicenseDetail</code> attribute **/
	public static final String CUSTOMERREGISTRATIONLICENSEDETAIL = "customerRegistrationLicenseDetail";
	/** Qualifier of the <code>IcommerceCustomerRegistration.customerRegistrationBillingAddress</code> attribute **/
	public static final String CUSTOMERREGISTRATIONBILLINGADDRESS = "customerRegistrationBillingAddress";
	/** Qualifier of the <code>IcommerceCustomerRegistration.exportStatus</code> attribute **/
	public static final String EXPORTSTATUS = "exportStatus";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(FIRSTNAME, AttributeMode.INITIAL);
		tmp.put(LASTNAME, AttributeMode.INITIAL);
		tmp.put(POSITION, AttributeMode.INITIAL);
		tmp.put(ROLE, AttributeMode.INITIAL);
		tmp.put(ORGANIZATIONNAME, AttributeMode.INITIAL);
		tmp.put(EMAILID, AttributeMode.INITIAL);
		tmp.put(OPTNOTIFY, AttributeMode.INITIAL);
		tmp.put(CUSTOMERREGISTRATIONLICENSEDETAIL, AttributeMode.INITIAL);
		tmp.put(CUSTOMERREGISTRATIONBILLINGADDRESS, AttributeMode.INITIAL);
		tmp.put(EXPORTSTATUS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.customerRegistrationBillingAddress</code> attribute.
	 * @return the customerRegistrationBillingAddress
	 */
	public CustomerRegistrationAddress getCustomerRegistrationBillingAddress(final SessionContext ctx)
	{
		return (CustomerRegistrationAddress)getProperty( ctx, CUSTOMERREGISTRATIONBILLINGADDRESS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.customerRegistrationBillingAddress</code> attribute.
	 * @return the customerRegistrationBillingAddress
	 */
	public CustomerRegistrationAddress getCustomerRegistrationBillingAddress()
	{
		return getCustomerRegistrationBillingAddress( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.customerRegistrationBillingAddress</code> attribute. 
	 * @param value the customerRegistrationBillingAddress
	 */
	public void setCustomerRegistrationBillingAddress(final SessionContext ctx, final CustomerRegistrationAddress value)
	{
		setProperty(ctx, CUSTOMERREGISTRATIONBILLINGADDRESS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.customerRegistrationBillingAddress</code> attribute. 
	 * @param value the customerRegistrationBillingAddress
	 */
	public void setCustomerRegistrationBillingAddress(final CustomerRegistrationAddress value)
	{
		setCustomerRegistrationBillingAddress( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.customerRegistrationLicenseDetail</code> attribute.
	 * @return the customerRegistrationLicenseDetail - CustomerRegistration License and shipping Details
	 */
	public CustomerRegistrationLicenseDetail getCustomerRegistrationLicenseDetail(final SessionContext ctx)
	{
		return (CustomerRegistrationLicenseDetail)getProperty( ctx, CUSTOMERREGISTRATIONLICENSEDETAIL);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.customerRegistrationLicenseDetail</code> attribute.
	 * @return the customerRegistrationLicenseDetail - CustomerRegistration License and shipping Details
	 */
	public CustomerRegistrationLicenseDetail getCustomerRegistrationLicenseDetail()
	{
		return getCustomerRegistrationLicenseDetail( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.customerRegistrationLicenseDetail</code> attribute. 
	 * @param value the customerRegistrationLicenseDetail - CustomerRegistration License and shipping Details
	 */
	public void setCustomerRegistrationLicenseDetail(final SessionContext ctx, final CustomerRegistrationLicenseDetail value)
	{
		setProperty(ctx, CUSTOMERREGISTRATIONLICENSEDETAIL,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.customerRegistrationLicenseDetail</code> attribute. 
	 * @param value the customerRegistrationLicenseDetail - CustomerRegistration License and shipping Details
	 */
	public void setCustomerRegistrationLicenseDetail(final CustomerRegistrationLicenseDetail value)
	{
		setCustomerRegistrationLicenseDetail( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.emailId</code> attribute.
	 * @return the emailId - email id of customer
	 */
	public String getEmailId(final SessionContext ctx)
	{
		return (String)getProperty( ctx, EMAILID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.emailId</code> attribute.
	 * @return the emailId - email id of customer
	 */
	public String getEmailId()
	{
		return getEmailId( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.emailId</code> attribute. 
	 * @param value the emailId - email id of customer
	 */
	public void setEmailId(final SessionContext ctx, final String value)
	{
		setProperty(ctx, EMAILID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.emailId</code> attribute. 
	 * @param value the emailId - email id of customer
	 */
	public void setEmailId(final String value)
	{
		setEmailId( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.exportStatus</code> attribute.
	 * @return the exportStatus
	 */
	public EnumerationValue getExportStatus(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, EXPORTSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.exportStatus</code> attribute.
	 * @return the exportStatus
	 */
	public EnumerationValue getExportStatus()
	{
		return getExportStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.exportStatus</code> attribute. 
	 * @param value the exportStatus
	 */
	public void setExportStatus(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, EXPORTSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.exportStatus</code> attribute. 
	 * @param value the exportStatus
	 */
	public void setExportStatus(final EnumerationValue value)
	{
		setExportStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.firstName</code> attribute.
	 * @return the firstName - first name of customer
	 */
	public String getFirstName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, FIRSTNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.firstName</code> attribute.
	 * @return the firstName - first name of customer
	 */
	public String getFirstName()
	{
		return getFirstName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.firstName</code> attribute. 
	 * @param value the firstName - first name of customer
	 */
	public void setFirstName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, FIRSTNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.firstName</code> attribute. 
	 * @param value the firstName - first name of customer
	 */
	public void setFirstName(final String value)
	{
		setFirstName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.lastName</code> attribute.
	 * @return the lastName - last name of customer
	 */
	public String getLastName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, LASTNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.lastName</code> attribute.
	 * @return the lastName - last name of customer
	 */
	public String getLastName()
	{
		return getLastName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.lastName</code> attribute. 
	 * @param value the lastName - last name of customer
	 */
	public void setLastName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, LASTNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.lastName</code> attribute. 
	 * @param value the lastName - last name of customer
	 */
	public void setLastName(final String value)
	{
		setLastName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute.
	 * @return the optNotify
	 */
	public Boolean isOptNotify(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, OPTNOTIFY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute.
	 * @return the optNotify
	 */
	public Boolean isOptNotify()
	{
		return isOptNotify( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute. 
	 * @return the optNotify
	 */
	public boolean isOptNotifyAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isOptNotify( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute. 
	 * @return the optNotify
	 */
	public boolean isOptNotifyAsPrimitive()
	{
		return isOptNotifyAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute. 
	 * @param value the optNotify
	 */
	public void setOptNotify(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, OPTNOTIFY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute. 
	 * @param value the optNotify
	 */
	public void setOptNotify(final Boolean value)
	{
		setOptNotify( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute. 
	 * @param value the optNotify
	 */
	public void setOptNotify(final SessionContext ctx, final boolean value)
	{
		setOptNotify( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.optNotify</code> attribute. 
	 * @param value the optNotify
	 */
	public void setOptNotify(final boolean value)
	{
		setOptNotify( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.organizationName</code> attribute.
	 * @return the organizationName - Organization Name
	 */
	public String getOrganizationName(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ORGANIZATIONNAME);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.organizationName</code> attribute.
	 * @return the organizationName - Organization Name
	 */
	public String getOrganizationName()
	{
		return getOrganizationName( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.organizationName</code> attribute. 
	 * @param value the organizationName - Organization Name
	 */
	public void setOrganizationName(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ORGANIZATIONNAME,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.organizationName</code> attribute. 
	 * @param value the organizationName - Organization Name
	 */
	public void setOrganizationName(final String value)
	{
		setOrganizationName( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.position</code> attribute.
	 * @return the position - last name of customer
	 */
	public String getPosition(final SessionContext ctx)
	{
		return (String)getProperty( ctx, POSITION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.position</code> attribute.
	 * @return the position - last name of customer
	 */
	public String getPosition()
	{
		return getPosition( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.position</code> attribute. 
	 * @param value the position - last name of customer
	 */
	public void setPosition(final SessionContext ctx, final String value)
	{
		setProperty(ctx, POSITION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.position</code> attribute. 
	 * @param value the position - last name of customer
	 */
	public void setPosition(final String value)
	{
		setPosition( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.role</code> attribute.
	 * @return the role - role name of customer
	 */
	public String getRole(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ROLE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegistration.role</code> attribute.
	 * @return the role - role name of customer
	 */
	public String getRole()
	{
		return getRole( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.role</code> attribute. 
	 * @param value the role - role name of customer
	 */
	public void setRole(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ROLE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegistration.role</code> attribute. 
	 * @param value the role - role name of customer
	 */
	public void setRole(final String value)
	{
		setRole( getSession().getSessionContext(), value );
	}
	
}
