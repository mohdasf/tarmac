/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 20, 2018 2:47:55 PM                     ---
 * ----------------------------------------------------------------
 */
package com.icommerceb2b.core.jalo;

import com.icommerce.core.constants.IcommerceCoreConstants;
import com.icommerce.core.jalo.IcommerceCustomerRegistration;
import de.hybris.platform.commerceservices.jalo.process.StoreFrontProcess;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.Currency;
import de.hybris.platform.jalo.c2l.Language;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link com.icommerceb2b.core.jalo.IcommerceCustomerRegEmailProcess IcommerceCustomerRegEmailProcess}.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedIcommerceCustomerRegEmailProcess extends StoreFrontProcess
{
	/** Qualifier of the <code>IcommerceCustomerRegEmailProcess.registeredUser</code> attribute **/
	public static final String REGISTEREDUSER = "registeredUser";
	/** Qualifier of the <code>IcommerceCustomerRegEmailProcess.language</code> attribute **/
	public static final String LANGUAGE = "language";
	/** Qualifier of the <code>IcommerceCustomerRegEmailProcess.currency</code> attribute **/
	public static final String CURRENCY = "currency";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(StoreFrontProcess.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(REGISTEREDUSER, AttributeMode.INITIAL);
		tmp.put(LANGUAGE, AttributeMode.INITIAL);
		tmp.put(CURRENCY, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegEmailProcess.currency</code> attribute.
	 * @return the currency - Attribute contains currency that will be used in the process.
	 */
	public Currency getCurrency(final SessionContext ctx)
	{
		return (Currency)getProperty( ctx, CURRENCY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegEmailProcess.currency</code> attribute.
	 * @return the currency - Attribute contains currency that will be used in the process.
	 */
	public Currency getCurrency()
	{
		return getCurrency( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegEmailProcess.currency</code> attribute. 
	 * @param value the currency - Attribute contains currency that will be used in the process.
	 */
	public void setCurrency(final SessionContext ctx, final Currency value)
	{
		setProperty(ctx, CURRENCY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegEmailProcess.currency</code> attribute. 
	 * @param value the currency - Attribute contains currency that will be used in the process.
	 */
	public void setCurrency(final Currency value)
	{
		setCurrency( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegEmailProcess.language</code> attribute.
	 * @return the language - Attribute contains language that will be used in the process.
	 */
	public Language getLanguage(final SessionContext ctx)
	{
		return (Language)getProperty( ctx, LANGUAGE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegEmailProcess.language</code> attribute.
	 * @return the language - Attribute contains language that will be used in the process.
	 */
	public Language getLanguage()
	{
		return getLanguage( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegEmailProcess.language</code> attribute. 
	 * @param value the language - Attribute contains language that will be used in the process.
	 */
	public void setLanguage(final SessionContext ctx, final Language value)
	{
		setProperty(ctx, LANGUAGE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegEmailProcess.language</code> attribute. 
	 * @param value the language - Attribute contains language that will be used in the process.
	 */
	public void setLanguage(final Language value)
	{
		setLanguage( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegEmailProcess.registeredUser</code> attribute.
	 * @return the registeredUser - Attribute contains customer object that will be used in the process.
	 */
	public IcommerceCustomerRegistration getRegisteredUser(final SessionContext ctx)
	{
		return (IcommerceCustomerRegistration)getProperty( ctx, REGISTEREDUSER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>IcommerceCustomerRegEmailProcess.registeredUser</code> attribute.
	 * @return the registeredUser - Attribute contains customer object that will be used in the process.
	 */
	public IcommerceCustomerRegistration getRegisteredUser()
	{
		return getRegisteredUser( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegEmailProcess.registeredUser</code> attribute. 
	 * @param value the registeredUser - Attribute contains customer object that will be used in the process.
	 */
	public void setRegisteredUser(final SessionContext ctx, final IcommerceCustomerRegistration value)
	{
		setProperty(ctx, REGISTEREDUSER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>IcommerceCustomerRegEmailProcess.registeredUser</code> attribute. 
	 * @param value the registeredUser - Attribute contains customer object that will be used in the process.
	 */
	public void setRegisteredUser(final IcommerceCustomerRegistration value)
	{
		setRegisteredUser( getSession().getSessionContext(), value );
	}
	
}
