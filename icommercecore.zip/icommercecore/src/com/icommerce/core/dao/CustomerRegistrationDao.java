/**
 *
 */
package com.icommerce.core.dao;

import java.util.List;

import com.icommerce.core.model.IcommerceCustomerRegistrationModel;


/**
 * @author 408744
 *
 */
public interface CustomerRegistrationDao
{
	boolean getCustomerWithEmail(final String emailId);

	List<IcommerceCustomerRegistrationModel> getRegistedCustomers();

	void markRegisteredUserAsExported(String emailId);
}
