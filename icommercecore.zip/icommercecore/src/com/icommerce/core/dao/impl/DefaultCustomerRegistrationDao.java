/**
 *
 */
package com.icommerce.core.dao.impl;

import de.hybris.platform.core.enums.ExportStatus;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.icommerce.core.dao.CustomerRegistrationDao;
import com.icommerce.core.model.IcommerceCustomerRegistrationModel;

import reactor.util.CollectionUtils;


/**
 * @author 408744
 *
 */
public class DefaultCustomerRegistrationDao implements CustomerRegistrationDao
{

	private static final Logger LOGGER = Logger.getLogger(DefaultCustomerRegistrationDao.class);

	@Autowired
	private FlexibleSearchService flexibleSearchService;

	@Autowired
	ModelService modelService;

	protected static final String GET_CUST_QUERY = "SELECT {" + IcommerceCustomerRegistrationModel.PK + "} " + "FROM {"
			+ IcommerceCustomerRegistrationModel._TYPECODE + "} WHERE " + "{" + IcommerceCustomerRegistrationModel.EMAILID
			+ "} = ?EMAILID";

	private static final String query = "SELECT {pk} FROM {IcommerceCustomerRegistration} WHERE {exportStatus}  IS NULL";

	/**
	 * getCustomerWithBillingAccount to verify weather the customer is already exists with same Email id.
	 *
	 * @param emailId
	 * @return boolean
	 */
	@Override
	public boolean getCustomerWithEmail(final String emailId)
	{
		LOGGER.debug("DefaultCustomerRegistrationDao :: getCustomerWithEmail Starts ::" + emailId.toLowerCase());
		boolean isCustExists = true;
		final FlexibleSearchQuery fQuery = new FlexibleSearchQuery(GET_CUST_QUERY);
		fQuery.addQueryParameter("EMAILID", emailId.toLowerCase());
		final SearchResult<IcommerceCustomerRegistrationModel> result = flexibleSearchService.search(fQuery);
		if (CollectionUtils.isEmpty(result.getResult()))
		{
			LOGGER.info(
					"DefaultCustomerRegistrationDao :: Customer with Email Id not exists. Hence Custmer is allowed to save in database");
			isCustExists = false;
		}

		LOGGER.debug("DefaultCustomerRegistrationDao :: getCustomerWithEmail Ends");
		return isCustExists;
	}

	/**
	 * getRegistedCustomers to get all the registered customers records with are not exported.
	 */
	@Override
	public List<IcommerceCustomerRegistrationModel> getRegistedCustomers()
	{
		final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(query);
		final SearchResult<IcommerceCustomerRegistrationModel> orderList = flexibleSearchService.search(searchQuery);
		return orderList.getResult();
	}

	/**
	 * markRegisteredUserAsExported to mark the registered user record as exported.
	 *
	 * @param emailId
	 */
	@Override
	public void markRegisteredUserAsExported(final String emailId)
	{
		final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(GET_CUST_QUERY);
		searchQuery.addQueryParameter("EMAILID", emailId.toLowerCase());
		final SearchResult<IcommerceCustomerRegistrationModel> orderList = flexibleSearchService.search(searchQuery);
		final List<IcommerceCustomerRegistrationModel> seqirusB2BCustomerRegistrationList = orderList.getResult();
		if (null != seqirusB2BCustomerRegistrationList && !seqirusB2BCustomerRegistrationList.isEmpty())
		{
			final IcommerceCustomerRegistrationModel seqirusB2BCustomerRegistrationModel = seqirusB2BCustomerRegistrationList.get(0);
			seqirusB2BCustomerRegistrationModel.setExportStatus(ExportStatus.EXPORTED);
			modelService.save(seqirusB2BCustomerRegistrationModel);
		}

	}


}
