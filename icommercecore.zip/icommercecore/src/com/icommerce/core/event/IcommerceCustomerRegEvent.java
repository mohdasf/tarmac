/**
 *
 */
package com.icommerce.core.event;

import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.servicelayer.event.events.AbstractEvent;
import de.hybris.platform.store.BaseStoreModel;

import com.icommerce.core.model.IcommerceCustomerRegistrationModel;


/**
 * @author 408744
 *
 */
public class IcommerceCustomerRegEvent<T extends BaseSiteModel> extends AbstractEvent
{
	private BaseStoreModel baseStore;
	private T site;
	private LanguageModel language;
	private CurrencyModel currency;
	private IcommerceCustomerRegistrationModel customerRegistration;


	/**
	 * @return the baseStore
	 */
	public BaseStoreModel getBaseStore()
	{
		return baseStore;
	}

	/**
	 * @param baseStore
	 *           the baseStore to set
	 */
	public void setBaseStore(final BaseStoreModel baseStore)
	{
		this.baseStore = baseStore;
	}

	/**
	 * @return the baseSite
	 */
	public T getSite()
	{
		return site;
	}

	/**
	 * @param site
	 *           the baseSite to set
	 */
	public void setSite(final T site)
	{
		this.site = site;
	}


	/**
	 * @return the language
	 */
	public LanguageModel getLanguage()
	{
		return language;
	}

	/**
	 * @param language
	 *           the language to set
	 */
	public void setLanguage(final LanguageModel language)
	{
		this.language = language;
	}

	/**
	 *
	 * @return CurrencyModel
	 */
	public CurrencyModel getCurrency()
	{
		return currency;
	}

	/**
	 *
	 * @param currency
	 */
	public void setCurrency(final CurrencyModel currency)
	{
		this.currency = currency;
	}

	/**
	 * @return the customerRegistration
	 */
	public IcommerceCustomerRegistrationModel getCustomerRegistration()
	{
		return customerRegistration;
	}

	/**
	 * @param customerRegistration
	 *           the customerRegistration to set
	 */
	public void setCustomerRegistration(final IcommerceCustomerRegistrationModel customerRegistration)
	{
		this.customerRegistration = customerRegistration;
	}

}

