/**
 *
 */
package com.icommerce.core.event;

import de.hybris.platform.acceleratorservices.site.AbstractAcceleratorSiteEventListener;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.commerceservices.enums.SiteChannel;
import de.hybris.platform.processengine.BusinessProcessService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import com.icommerceb2b.core.model.IcommerceCustomerRegEmailProcessModel;




/**
 * LscareB2BCustomerRegEventListener
 *
 */
public class IcommerceCustomerRegEventListener extends AbstractAcceleratorSiteEventListener<IcommerceCustomerRegEvent>
{

	private ModelService modelService;
	private BusinessProcessService businessProcessService;

	/**
	 * @return the modelService
	 */
	public ModelService getModelService()
	{
		return modelService;
	}

	/**
	 * @param modelService
	 *           the modelService to set
	 */
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	/**
	 * @return the businessProcessService
	 */
	public BusinessProcessService getBusinessProcessService()
	{
		return businessProcessService;
	}

	/**
	 * @param businessProcessService
	 *           the businessProcessService to set
	 */
	public void setBusinessProcessService(final BusinessProcessService businessProcessService)
	{
		this.businessProcessService = businessProcessService;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * de.hybris.platform.acceleratorservices.site.AbstractAcceleratorSiteEventListener#getSiteChannelForEvent(de.hybris.
	 * platform.servicelayer.event.events.AbstractEvent)
	 */
	@Override
	protected SiteChannel getSiteChannelForEvent(final IcommerceCustomerRegEvent event)
	{
		final BaseSiteModel site = event.getSite();
		ServicesUtil.validateParameterNotNullStandardMessage("event.site", site);
		return site.getChannel();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * de.hybris.platform.commerceservices.event.AbstractSiteEventListener#onSiteEvent(de.hybris.platform.servicelayer.
	 * event.events.AbstractEvent)
	 */
	@Override
	protected void onSiteEvent(final IcommerceCustomerRegEvent event)
	{
		final IcommerceCustomerRegEmailProcessModel lscareCustomerProcessModel = (IcommerceCustomerRegEmailProcessModel) getBusinessProcessService()
				.createProcess("lscareb2bCustomerRegEmailProcess-" + "-" + System.currentTimeMillis(),
						"lscareb2bCustomerRegEmailProcess");
		lscareCustomerProcessModel.setRegisteredUser(event.getCustomerRegistration());
		lscareCustomerProcessModel.setSite(event.getSite());
		lscareCustomerProcessModel.setLanguage(event.getLanguage());
		lscareCustomerProcessModel.setCurrency(event.getCurrency());
		lscareCustomerProcessModel.setStore(event.getBaseStore());
		getModelService().save(lscareCustomerProcessModel);
		getBusinessProcessService().startProcess(lscareCustomerProcessModel);
	}
}

