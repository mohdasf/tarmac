/**
 *
 */
package com.icommerce.core.exceptions;

/**
 * @author 408744
 *
 */
public class IcommerceBusinessException extends Exception
{

	private static final String TYPE = "Validation Error";
	private static final String SUBJECT_TYPE = "Business";

	/**
	 * @param message
	 */
	public IcommerceBusinessException(final String message)
	{
		super(message);
	}


}
