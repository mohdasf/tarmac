/**
 *
 */
package com.icommerce.core.order.dao;


import com.icommerce.core.model.IcommerceCustomerRegistrationModel;


/**
 * SeqirusCustomerLicenseInfoDao interface.
 */
public interface IcommerceCustomerLicenseInfoDao
{
	public IcommerceCustomerRegistrationModel getLicenseInfo(String emailId);

}
