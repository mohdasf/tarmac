/**
 *
 */
package com.icommerce.core.order.dao.impl;




import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;
import de.hybris.platform.servicelayer.user.UserService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.icommerce.core.model.IcommerceCustomerRegistrationModel;
import com.icommerce.core.order.dao.IcommerceCustomerLicenseInfoDao;





/**
 * This class will load the Customer registration data.
 */
public class IcommerceCustomerLicenseInfoDaoImpl implements IcommerceCustomerLicenseInfoDao
{

	@Autowired
	private FlexibleSearchService flexibleSearchService;

	@Autowired
	UserService userService;

	private static final String query = "SELECT {pk} FROM {LscareB2BCustomerRegistration} WHERE {emailId} = ?userEmailId";

	/**
	 * This method will load the customer registration data with emailid.
	 */
	@Override
	public IcommerceCustomerRegistrationModel getLicenseInfo(final String emailId)
	{
		final FlexibleSearchQuery searchQuery = new FlexibleSearchQuery(query);
		searchQuery.addQueryParameter("userEmailId", emailId);
		final SearchResult<IcommerceCustomerRegistrationModel> customersList = flexibleSearchService.search(searchQuery);
		if (null != customersList)
		{
			final List<IcommerceCustomerRegistrationModel> customers = customersList.getResult();
			if (null != customers && !customers.isEmpty())
			{
				return customers.get(0);
			}
		}
		return null;
	}


}
