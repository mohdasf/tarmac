package com.icommerce.core.services;

/**
 * CustomerRegistrationService
 *
 */
public interface CustomerRegistrationService
{
	boolean getCustomerWithEmail(final String emailId);
}
