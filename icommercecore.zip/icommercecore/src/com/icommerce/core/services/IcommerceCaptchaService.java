package com.icommerce.core.services;

/**
 * this SeqirusCaptchaService will use to validate the captcha response
 *
 */
public interface IcommerceCaptchaService
{
	boolean validateCaptchaResponse(final String response);
}
