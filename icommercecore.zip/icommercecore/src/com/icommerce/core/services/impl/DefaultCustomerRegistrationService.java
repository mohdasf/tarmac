package com.icommerce.core.services.impl;

import de.hybris.platform.servicelayer.model.ModelService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.icommerce.core.dao.CustomerRegistrationDao;
import com.icommerce.core.services.CustomerRegistrationService;




/**
 * DefaultCustomerRegistrationService
 *
 */

public class DefaultCustomerRegistrationService implements CustomerRegistrationService
{
	private static final Logger LOGGER = Logger.getLogger(CustomerRegistrationService.class);

	@Autowired
	ModelService modelService;

	@Autowired
	CustomerRegistrationDao customerRegistrationDao;

	/**
	 * @return the customerRegistrationDao
	 */
	public CustomerRegistrationDao getCustomerRegistrationDao()
	{
		return customerRegistrationDao;
	}

	/**
	 * @param customerRegistrationDao
	 *           the customerRegistrationDao to set
	 */
	public void setCustomerRegistrationDao(final CustomerRegistrationDao customerRegistrationDao)
	{
		this.customerRegistrationDao = customerRegistrationDao;
	}

	/**
	 * getCustomerWithBillingAccount to verify weather the customer is already exists with same email id.
	 *
	 * @param emailId
	 * @return boolean
	 *
	 */

	@Override
	public boolean getCustomerWithEmail(final String emailId)
	{
		LOGGER.debug("DefaultCustomerRegistrationService :: getCustomerWithEmail Starts ::" + emailId);
		final boolean customerDoesExist = customerRegistrationDao.getCustomerWithEmail(emailId);
		LOGGER.debug("DefaultCustomerRegistrationService ::  getCustomerWithEmail Ends ::");

		return customerDoesExist;
	}
}
