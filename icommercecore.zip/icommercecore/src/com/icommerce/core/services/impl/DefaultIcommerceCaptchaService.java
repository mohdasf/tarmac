package com.icommerce.core.services.impl;

import de.hybris.platform.acceleratorservices.config.SiteConfigService;

import java.net.URLEncoder;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.icommerce.core.services.IcommerceCaptchaService;

import net.tanesha.recaptcha.ReCaptchaException;
import net.tanesha.recaptcha.http.HttpLoader;


/**
 * this LscareCaptchaService will use to validate the captcha response
 *
 */
public class DefaultIcommerceCaptchaService implements IcommerceCaptchaService
{

	private static final Logger LOG = Logger.getLogger(IcommerceCaptchaService.class);

	private static final String RECAPTCHA_SECRET_KEY = "recaptcha.privatekey.lscareb2b-us";
	private static final String RECAPTCHA_VARIFICATION_URL = "recaptcha.verification.url";

	private static final String TRUE = "true";

	private static final String SPLIT_STRING = "\r?\n";
	private static final String EMPTY_RESPONSE = "No answer returned from recaptcha: ";
	private static final String SECRET_PARAM = "secret=";
	private static final String RESPONSE_PARAM = "&response=";


	@Resource
	private HttpLoader icommerceHttpLoader;

	@Resource(name = "siteConfigService")
	private SiteConfigService siteConfigService;

	/**
	 * Method for validating re-Captcha Response from recaptcha verification server.
	 *
	 * @param response
	 * @return Boolean
	 */
	@SuppressWarnings("deprecation")
	@Override
	public boolean validateCaptchaResponse(final String response)
	{
		boolean valid = false;

		if (StringUtils.isNotEmpty(response))
		{
			final String postParameters = SECRET_PARAM + URLEncoder.encode(siteConfigService.getProperty(RECAPTCHA_SECRET_KEY))
					+ RESPONSE_PARAM + URLEncoder.encode(response);

			try
			{
				LOG.info("trring to connect to recaptcha verification server...");
				final String message = icommerceHttpLoader.httpPost(siteConfigService.getProperty(RECAPTCHA_VARIFICATION_URL),
						postParameters);

				final String[] a = StringUtils.split(message, SPLIT_STRING);
				if (null == a || a.length < 1)
				{
					LOG.error(EMPTY_RESPONSE + message);
				}
				else
				{
					valid = a[1].contains(TRUE);
				}
			}
			catch (final ReCaptchaException ex)
			{
				LOG.error("could not connect to RECAPTCHA-VARIFICATION server, exception: " + ex.getMessage(), ex);
			}
			catch (final Exception ex)
			{
				LOG.error("some exception occurred in captcha functionality: exception: " + ex.getMessage(), ex);
			}
		}

		return valid;
	}

}
