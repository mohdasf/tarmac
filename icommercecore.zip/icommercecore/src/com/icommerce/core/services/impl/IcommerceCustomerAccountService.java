package com.icommerce.core.services.impl;

import de.hybris.platform.commerceservices.customer.TokenInvalidatedException;
import de.hybris.platform.commerceservices.customer.impl.DefaultCustomerAccountService;
import de.hybris.platform.commerceservices.security.SecureToken;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.solr.common.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

/**
 * SeqirusCustomerAccountService - can update and create password for B2BCustomer
 *
 */
public class IcommerceCustomerAccountService extends DefaultCustomerAccountService
{
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(IcommerceCustomerAccountService.class);
	private long generatePwdTokenValiditySeconds;
	private long forgottenPwdTokenValiditySeconds;
	@Autowired
	private ConfigurationService configurationService;
	@Override
	public void updatePassword(final String token, final String newPassword) throws TokenInvalidatedException
	{
		Assert.hasText(token, "The field [token] cannot be empty");
		Assert.hasText(newPassword, "The field [newPassword] cannot be empty");
		generatePwdTokenValiditySeconds = configurationService.getConfiguration().getLong("b2bcustomer.pwd.generation.tokenValiditySeconds");
		forgottenPwdTokenValiditySeconds = configurationService.getConfiguration().getLong("b2bcustomer.forgottenpwd.tokenValiditySeconds");
		final SecureToken data = getSecureTokenService().decryptData(token);
		final CustomerModel customer = getUserService().getUserForUID(data.getData(), CustomerModel.class);
		if (customer == null)
		{
			throw new IllegalArgumentException("user for token not found");
		}
		if(StringUtils.isEmpty(customer.getEncodedPassword()))
		{
			if (generatePwdTokenValiditySeconds < 0)
			{
				throw new IllegalArgumentException("tokenValiditySeconds has to be >= 0");
			}
			if (generatePwdTokenValiditySeconds > 0L)
			{
				final long delta = new Date().getTime() - data.getTimeStamp();
				if (delta / 1000 > generatePwdTokenValiditySeconds)
				{
					throw new IllegalArgumentException("Password token expired");
				}
			}
		}
		else
		{
			if (forgottenPwdTokenValiditySeconds < 0)
			{
				throw new IllegalArgumentException("tokenValiditySeconds has to be >= 0");
			}
			if (forgottenPwdTokenValiditySeconds > 0L)
			{
				final long delta = new Date().getTime() - data.getTimeStamp();
				if (delta / 1000 > forgottenPwdTokenValiditySeconds)
				{
					throw new IllegalArgumentException("Password token expired");
				}
			}
		}
		if (!token.equals(customer.getToken()))
		{
			throw new TokenInvalidatedException();
		}
		customer.setToken(null);
		customer.setLoginDisabled(false);
		getModelService().save(customer);
		getUserService().setPassword(data.getData(), newPassword, getPasswordEncoding());
	}
}
