/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 20, 2018 2:47:55 PM                     ---
 * ----------------------------------------------------------------
 */
package com.icommerce.facades.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedIcommerceFacadesConstants
{
	public static final String EXTENSIONNAME = "icommercefacades";
	
	protected GeneratedIcommerceFacadesConstants()
	{
		// private constructor
	}
	
	
}
