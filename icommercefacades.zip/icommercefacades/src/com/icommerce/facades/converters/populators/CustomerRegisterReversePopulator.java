package com.icommerce.facades.converters.populators;


import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.model.ModelService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import com.icommerce.core.model.CustomerRegistrationAddressModel;
import com.icommerce.core.model.CustomerRegistrationLicenseDetailModel;
import com.icommerce.core.model.IcommerceCustomerRegistrationModel;
import com.icommerce.facades.cutomer.data.IcommerceCustomerRegistrationData;
import com.thoughtworks.xstream.converters.ConversionException;


/**
 * CustomerRegisterReversePopulator to convert the data from LscareB2BCustomerRegistrationData object to
 * LscareB2BCustomerRegistrationModel object.
 */
public class CustomerRegisterReversePopulator
		implements Populator<IcommerceCustomerRegistrationData, IcommerceCustomerRegistrationModel>
{
	private static final Logger LOGGER = Logger.getLogger(CustomerRegisterReversePopulator.class);


	private ModelService modelService;


	/**
	 * method to populate LscareB2BCustomerRegistrationModel type from LscareB2BCustomerRegistrationData.
	 *
	 * @param source
	 * @param target
	 */
	@Override
	public void populate(final IcommerceCustomerRegistrationData source, final IcommerceCustomerRegistrationModel target)
			throws ConversionException
	{

		LOGGER.debug("CustomerRegisterReversePopulator Starts");
		if (source != null)
		{
			if (source.getFirstName() != null)
			{
				target.setFirstName(source.getFirstName());
			}
			if (source.getLastName() != null)
			{
				target.setLastName(source.getLastName());
			}

			if (source.getEmailId() != null)
			{
				target.setEmailId(source.getEmailId());
			}

			if (source.getPosition() != null)
			{
				target.setPosition(source.getPosition());
			}

			if (source.getOrganizationName() != null)
			{
				target.setOrganizationName(source.getOrganizationName());
			}
			target.setOptNotify(Boolean.valueOf(source.isOptNotify()));

			if (source.getBillingAddress() != null)
			{
				final CustomerRegistrationAddressModel billingAddress = modelService.create(CustomerRegistrationAddressModel.class);

				billingAddress.setOwner(target);
				billingAddress.setIsSameAsShippingAddress(source.getBillingAddress().isIsSameAsShippingAddress());

				if (source.getBillingAddress().getOrganizationName() != null)
				{
					billingAddress.setOrganizationName(source.getBillingAddress().getOrganizationName());
				}

				if (source.getBillingAddress().getLine1() != null)
				{
					billingAddress.setLine1(source.getBillingAddress().getLine1());
				}
				if (source.getBillingAddress().getTown() != null)
				{
					billingAddress.setTown(source.getBillingAddress().getTown());
				}
				if (source.getBillingAddress().getState() != null)
				{
					billingAddress.setState(source.getBillingAddress().getState());
				}
				if (source.getBillingAddress().getPostalCode() != null)
				{
					billingAddress.setPostalcode(source.getBillingAddress().getPostalCode());
				}
				if (source.getBillingAddress().getPhone() != null)
				{
					billingAddress.setPhone1(source.getBillingAddress().getPhone());
				}
				modelService.save(billingAddress);
				target.setCustomerRegistrationBillingAddress(billingAddress);
			}

			// license and shipping details

			if (source.getLicenseDetails() != null)
			{
				final CustomerRegistrationLicenseDetailModel customerLicenseModel = modelService
						.create(CustomerRegistrationLicenseDetailModel.class);

				customerLicenseModel.setIsFederalOrganization(source.getLicenseDetails().isIsFederalOrganization());
				if (source.getLicenseDetails().getLicenseName() != null)
				{
					customerLicenseModel.setLicenceName(source.getLicenseDetails().getLicenseName());
				}

				if (source.getLicenseDetails().getLicenseStateNumber() != null)
				{
					customerLicenseModel.setLicenceStateNumber(source.getLicenseDetails().getLicenseStateNumber());
				}

				if (source.getLicenseDetails().getLicexpiryDate() != null)
				{
					Date date = null;
					try
					{
						date = new SimpleDateFormat("MM/dd/yyyy").parse(source.getLicenseDetails().getLicexpiryDate());
						LOGGER.debug("Date Value after parse" + date);
					}
					catch (final ParseException e)
					{
						LOGGER.error("Date Parse exception in populator", e);
					}
					customerLicenseModel.setLicenceExpiryDate(date);
				}

				if (source.getLicenseDetails().getLicenceAddressLine1() != null)
				{
					customerLicenseModel.setLicenceAddressLine1(source.getLicenseDetails().getLicenceAddressLine1());
				}

				if (source.getLicenseDetails().getStateIssuingLicence() != null)
				{
					customerLicenseModel.setStateIssuingLicence(source.getLicenseDetails().getStateIssuingLicence());
				}

				if (source.getLicenseDetails().getHoursOfOperation() != null)
				{
					customerLicenseModel.setHoursOfOperation(source.getLicenseDetails().getHoursOfOperation());
				}

				final CustomerRegistrationAddressModel shippingAddressModel = modelService
						.create(CustomerRegistrationAddressModel.class);

				if (source.getLicenseDetails().getShippingAddress() != null)
				{
					shippingAddressModel.setOwner(target);

					if (source.getLicenseDetails().getOrganizationName() != null)
					{
						shippingAddressModel.setOrganizationName(source.getLicenseDetails().getOrganizationName());
					}

					if (source.getLicenseDetails().getShippingAddress().getLine1() != null)
					{
						shippingAddressModel.setLine1(source.getLicenseDetails().getShippingAddress().getLine1());
					}

					if (source.getLicenseDetails().getShippingAddress().getTown() != null)
					{
						shippingAddressModel.setTown(source.getLicenseDetails().getShippingAddress().getTown());
					}
					if (source.getLicenseDetails().getShippingAddress().getState() != null)
					{
						shippingAddressModel.setState(source.getLicenseDetails().getShippingAddress().getState());
					}
					if (source.getLicenseDetails().getShippingAddress().getPostalCode() != null)
					{
						shippingAddressModel.setPostalcode(source.getLicenseDetails().getShippingAddress().getPostalCode());
					}
					if (source.getLicenseDetails().getShippingAddress().getPhone() != null)
					{
						shippingAddressModel.setPhone1(source.getLicenseDetails().getShippingAddress().getPhone());
					}
					modelService.save(shippingAddressModel);
					customerLicenseModel.setCustomerRegistrationShippingAddress(shippingAddressModel);
				}
				modelService.save(customerLicenseModel);
				target.setCustomerRegistrationLicenseDetail(customerLicenseModel);
			}
		}
		LOGGER.debug("CustomerRegisterReversePopulator Ends ::");
	}

	protected ModelService getModelService()
	{
		return modelService;
	}

	@Required
	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}
}
