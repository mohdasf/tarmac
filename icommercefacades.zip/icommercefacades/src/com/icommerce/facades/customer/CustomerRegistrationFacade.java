
package com.icommerce.facades.customer;

import com.icommerce.core.exceptions.IcommerceBusinessException;
import com.icommerce.facades.cutomer.data.IcommerceCustomerRegistrationData;


/**
 * CustomerRegistrationFacade for customer registraiton
 *
 */
public interface CustomerRegistrationFacade
{

	void registerCustomerRequest(IcommerceCustomerRegistrationData seqCustRegisterData) throws IcommerceBusinessException;

	boolean isCustomerExist(String emailId);

}
