package com.icommerce.facades.customer;

import com.icommerce.core.model.IcommerceCustomerRegistrationModel;


/**
 * SeqirusCustomerLicenseInfoFacade interface.
 */
public interface IcommerceCustomerLicenseInfoFacade
{
	public IcommerceCustomerRegistrationModel getCustomerLicenseInfo(String emailId);
}
