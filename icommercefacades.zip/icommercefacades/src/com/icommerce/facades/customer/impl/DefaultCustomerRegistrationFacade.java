package com.icommerce.facades.customer.impl;

import de.hybris.platform.b2b.model.B2BCustomerModel;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.event.EventService;
import de.hybris.platform.servicelayer.event.events.AbstractEvent;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.site.BaseSiteService;
import de.hybris.platform.store.services.BaseStoreService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.icommerce.core.event.IcommerceCustomerExportEvent;
import com.icommerce.core.event.IcommerceCustomerRegEvent;
import com.icommerce.core.exceptions.IcommerceBusinessException;
import com.icommerce.core.model.IcommerceCustomerRegistrationModel;
import com.icommerce.core.services.CustomerRegistrationService;
import com.icommerce.facades.customer.CustomerRegistrationFacade;
import com.icommerce.facades.cutomer.data.IcommerceCustomerRegistrationData;




/**
 * DefaultCustomerRegistrationFacade deals with customer register data and sending email
 *
 */

public class DefaultCustomerRegistrationFacade implements CustomerRegistrationFacade
{

	private static final Logger LOGGER = Logger.getLogger(DefaultCustomerRegistrationFacade.class);

	@Autowired
	private CustomerRegistrationService customerRegistrationService;

	@Autowired
	private ModelService modelService;
	@Autowired
	private EventService eventService;
	@Autowired
	private BaseStoreService baseStoreService;
	@Autowired
	private BaseSiteService baseSiteService;
	@Autowired
	private CommonI18NService commonI18NService;

	@Autowired
	UserService userService;


	public CustomerRegistrationService getCustomerRegistrationService()
	{
		return customerRegistrationService;
	}

	public void setCustomerRegistrationService(final CustomerRegistrationService customerRegistrationService)
	{
		this.customerRegistrationService = customerRegistrationService;
	}

	protected Populator<IcommerceCustomerRegistrationData, IcommerceCustomerRegistrationModel> customerRegistrationReversePopulator;


	/**
	 * @return the customerRegistrationReversePopulator
	 */
	public Populator<IcommerceCustomerRegistrationData, IcommerceCustomerRegistrationModel> getCustomerRegistrationReversePopulator()
	{
		return customerRegistrationReversePopulator;
	}

	/**
	 * @param customerRegistrationReversePopulator
	 *           the customerRegistrationReversePopulator to set
	 */
	public void setCustomerRegistrationReversePopulator(
			final Populator<IcommerceCustomerRegistrationData, IcommerceCustomerRegistrationModel> customerRegistrationReversePopulator)
	{
		this.customerRegistrationReversePopulator = customerRegistrationReversePopulator;
	}


	/**
	 * This functionality to Register the lscare customer data to hybris
	 *
	 * @param seqCustRegisterData
	 * @throws LscareBusinessException
	 *
	 */
	@Override
	public void registerCustomerRequest(final IcommerceCustomerRegistrationData seqCustRegisterData)
			throws IcommerceBusinessException
	{
		LOGGER.debug(" registerCustomerRequest of Facade Starts ::");
		if (isCustomerExists(seqCustRegisterData))
		{
			LOGGER.error("Customer With EmailId: " + seqCustRegisterData.getEmailId() + "Already Exists..!! ");
			throw new IcommerceBusinessException(
					seqCustRegisterData.getEmailId() + " Already Exists..!! Please try with an Other Email");
		}
		else
		{
			final IcommerceCustomerRegistrationModel lscareCustomerRegistrationModel = createLscareCustomer(seqCustRegisterData);
			sendEmail(lscareCustomerRegistrationModel);
			LOGGER.debug(" registerCustomerRequest of Facade Ends ::");
		}
	}

	public boolean isCustomerExists(final IcommerceCustomerRegistrationData seqCustRegisterData)
	{
		LOGGER.debug("isCustomerExistsWithEmail Starts ::" + seqCustRegisterData.getEmailId());
		return isCustomerExist(seqCustRegisterData.getEmailId());
	}

	@Override
	public boolean isCustomerExist(final String emailId)
	{
		boolean isCustomerExists = false;
		LOGGER.debug("isCustomerExistsWithEmail Starts with ajax call::" + emailId);
		B2BCustomerModel userForUID = null;
		try
		{
			userForUID = userService.getUserForUID(emailId.toLowerCase(), B2BCustomerModel.class);
		}
		catch (final Exception e)
		{
			LOGGER.debug("Customer with ::" + emailId + "is not exists.Hence customer is allowing to save");
		}
		if (null != userForUID || customerRegistrationService.getCustomerWithEmail(emailId))
		{
			isCustomerExists = true;
		}
		return isCustomerExists;
	}

	/**
	 * Save cutomer details
	 *
	 */
	private IcommerceCustomerRegistrationModel createLscareCustomer(final IcommerceCustomerRegistrationData seqCustRegisterData)
	{
		final IcommerceCustomerRegistrationModel lscareCustomerRegistrationModel = modelService
				.create(IcommerceCustomerRegistrationModel.class);
		getCustomerRegistrationReversePopulator().populate(seqCustRegisterData, lscareCustomerRegistrationModel);
		modelService.saveAll(lscareCustomerRegistrationModel);
		return lscareCustomerRegistrationModel;
	}

	/**
	 * Send email to registered customers
	 */
	private void sendEmail(final IcommerceCustomerRegistrationModel lscareCustomerRegistrationModel)
	{
		// Triggering email event for registration
		try
		{
			LOGGER.info("Sending Customer Registration Email to the Customer.");
			eventService.publishEvent(initializeEvent(new IcommerceCustomerRegEvent(), lscareCustomerRegistrationModel));
			LOGGER.info("Registration Email Sent to the customer successfully.");
			LOGGER.info("Sending Customer Registration Email to the CustomerService.");
			eventService.publishEvent(initializeExportEvent(new IcommerceCustomerExportEvent(), lscareCustomerRegistrationModel));
			LOGGER.info("Registration Email Sent to the CustomerService successfully.");
		}
		catch (final Exception e)
		{
			LOGGER.error("Exception while sending email to registered customer :" + e.getMessage());
		}
	}

	/**
	 * @param lscareB2BCustomerExportEvent
	 * @param lscareCustomerRegistrationModel
	 * @return event
	 */
	private AbstractEvent initializeExportEvent(final IcommerceCustomerExportEvent event,
			final IcommerceCustomerRegistrationModel lscareCustomerRegistrationModel)
	{
		event.setBaseStore(baseStoreService.getCurrentBaseStore());
		event.setSite(baseSiteService.getCurrentBaseSite());
		event.setCustomerRegistration(lscareCustomerRegistrationModel);
		event.setLanguage(commonI18NService.getCurrentLanguage());
		event.setCurrency(commonI18NService.getCurrentCurrency());
		return event;
	}

	private IcommerceCustomerRegEvent initializeEvent(final IcommerceCustomerRegEvent event,
			final IcommerceCustomerRegistrationModel lscareCustomerRegistrationModel)
	{
		event.setBaseStore(baseStoreService.getCurrentBaseStore());
		event.setSite(baseSiteService.getCurrentBaseSite());
		event.setCustomerRegistration(lscareCustomerRegistrationModel);
		event.setLanguage(commonI18NService.getCurrentLanguage());
		event.setCurrency(commonI18NService.getCurrentCurrency());
		return event;
	}

}
