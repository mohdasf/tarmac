/**
 *
 */
package com.icommerce.facades.customer.impl;



import org.springframework.beans.factory.annotation.Autowired;

import com.icommerce.core.model.IcommerceCustomerRegistrationModel;
import com.icommerce.core.order.dao.IcommerceCustomerLicenseInfoDao;
import com.icommerce.facades.customer.IcommerceCustomerLicenseInfoFacade;


/**
 * This class will get the license data from dao class and pass the data to controller.
 */
public class IcommerceCustomerLicenseInfoFacadeImpl implements IcommerceCustomerLicenseInfoFacade
{

	@Autowired
	IcommerceCustomerLicenseInfoDao lscareCustomerLicenseInfoDao;

	/**
	 * This method will dao and get teh license data.
	 */
	@Override
	public IcommerceCustomerRegistrationModel getCustomerLicenseInfo(final String emailId)
	{
		if (null != emailId)
		{
			return lscareCustomerLicenseInfoDao.getLicenseInfo(emailId);
		}
		return null;
	}

}
