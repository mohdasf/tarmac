package com.icommerce.facades.process.email.context;

import de.hybris.platform.acceleratorservices.model.cms2.pages.EmailPageModel;
import de.hybris.platform.acceleratorservices.process.email.context.AbstractEmailContext;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.cms2.model.contents.components.CMSLinkComponentModel;
import de.hybris.platform.cms2.model.pages.PageTemplateModel;
import de.hybris.platform.cms2.model.relations.ContentSlotForTemplateModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.icommerce.core.model.IcommerceCustomerRegistrationModel;
import com.icommerceb2b.core.model.IcommerceCustomerRegEmailProcessModel;


/**
 * Lscareb2bRegistrationEmailContext class to render data in email template
 *
 */
public class IcommerceRegDetailsEmailContext extends AbstractEmailContext<IcommerceCustomerRegEmailProcessModel>
{
	private IcommerceCustomerRegistrationModel regCustomer;
	private static final String L_NAME = "lastName";
	private static final String POSITION = "position";
	private static final String ORGANIZATION_NAME = "organizationName";
	private static final String ISFEDERALORGANIZATION = "isFederalOrganization";
	private static final String LIC_NAME = "licenceName";
	private static final String LIC_STATE_NUMBER = "licenceStateNumber";
	private static final String LIC_EXP_DATE = "licenceExpiryDate";
	private static final String LIC_INSURANCE_STATE = "licenseInsuranceState";
	private static final String LIC_ADD_1 = "licenseAddress1";
	private static final String SHIP_ADDR_ORG = "shippingOrganizationName";
	private static final String SHIP_STATE = "shipState";
	private static final String SHIP_ADDR_LINE1 = "shipAddrLine1";
	private static final String SHIP_ADDR_ZIP = "shipAddrZip";
	private static final String SHIP_ADDR_CITY = "shipAddrCity";
	private static final String SHIP_ADDR_PHONE = "shipAddrPhone";
	private static final String ISSAMEASSHIPPINGADDRESS = "isSameAsShippingAddress";
	private static final String BILL_ADDR_ORG = "billOrganizationName";
	private static final String BILL_STATE = "billState";
	private static final String BILL_ADDR_LINE1 = "billAddrLine1";
	private static final String BILL_ADDR_ZIP = "billAddrZip";
	private static final String BILL_ADDR_CITY = "billAddrCity";
	private static final String BILL_ADDR_PHONE = "billAddrPhone";
	private static final String HOURS_OF_OPERATION = "hoursOfOperation";
	private static final String CUST_EMAIL = "customerEmail";
	public static final String FOOTER_COMPONENTS = "footerComponents";
	public static final String DASHBOARD_LINK = "dashboardLink";

	@Autowired
	ConfigurationService configurationService;

	/**
	 * @return the regCustomer
	 */
	public IcommerceCustomerRegistrationModel getRegCustomer()
	{
		return regCustomer;
	}

	/**
	 * @param regCustomer
	 *           the regCustomer to set
	 */
	public void setRegCustomer(final IcommerceCustomerRegistrationModel regCustomer)
	{
		this.regCustomer = regCustomer;
	}

	@Override
	public void init(final IcommerceCustomerRegEmailProcessModel lscareB2BCustomerRegEmailProcess,
			final EmailPageModel emailPageModel)
	{
		super.init(lscareB2BCustomerRegEmailProcess, emailPageModel);
		regCustomer = lscareB2BCustomerRegEmailProcess.getRegisteredUser();

		put(EMAIL, configurationService.getConfiguration().getString("registration.export.mail.to"));
		put(CUST_EMAIL, regCustomer.getEmailId());
		put(DISPLAY_NAME, regCustomer.getFirstName());
		put(L_NAME, regCustomer.getLastName());
		put(POSITION, regCustomer.getPosition());
		put(ORGANIZATION_NAME, regCustomer.getOrganizationName());
		put(ISFEDERALORGANIZATION, regCustomer.getCustomerRegistrationLicenseDetail().getIsFederalOrganization());
		put(LIC_NAME, regCustomer.getCustomerRegistrationLicenseDetail().getLicenceName());
		put(LIC_STATE_NUMBER, regCustomer.getCustomerRegistrationLicenseDetail().getLicenceStateNumber());
		put(LIC_EXP_DATE, dateFormat(regCustomer.getCustomerRegistrationLicenseDetail().getLicenceExpiryDate()));
		put(LIC_INSURANCE_STATE, regCustomer.getCustomerRegistrationLicenseDetail().getStateIssuingLicence());
		put(LIC_ADD_1, regCustomer.getCustomerRegistrationLicenseDetail().getLicenceAddressLine1());
		put(SHIP_ADDR_ORG,
				regCustomer.getCustomerRegistrationLicenseDetail().getCustomerRegistrationShippingAddress().getOrganizationName());
		put(SHIP_STATE, regCustomer.getCustomerRegistrationLicenseDetail().getCustomerRegistrationShippingAddress().getState());
		put(SHIP_ADDR_LINE1,
				regCustomer.getCustomerRegistrationLicenseDetail().getCustomerRegistrationShippingAddress().getLine1());
		put(SHIP_ADDR_ZIP,
				regCustomer.getCustomerRegistrationLicenseDetail().getCustomerRegistrationShippingAddress().getPostalcode());
		put(SHIP_ADDR_CITY, regCustomer.getCustomerRegistrationLicenseDetail().getCustomerRegistrationShippingAddress().getTown());
		put(SHIP_ADDR_PHONE, phoneNumberFormat(
				regCustomer.getCustomerRegistrationLicenseDetail().getCustomerRegistrationShippingAddress().getPhone1()));
		put(ISSAMEASSHIPPINGADDRESS, regCustomer.getCustomerRegistrationBillingAddress().getIsSameAsShippingAddress());
		put(BILL_ADDR_ORG, regCustomer.getCustomerRegistrationBillingAddress().getOrganizationName());
		put(BILL_STATE, regCustomer.getCustomerRegistrationBillingAddress().getState());
		put(BILL_ADDR_LINE1, regCustomer.getCustomerRegistrationBillingAddress().getLine1());
		put(BILL_ADDR_ZIP, regCustomer.getCustomerRegistrationBillingAddress().getPostalcode());
		put(BILL_ADDR_CITY, regCustomer.getCustomerRegistrationBillingAddress().getTown());
		put(BILL_ADDR_PHONE, phoneNumberFormat(regCustomer.getCustomerRegistrationBillingAddress().getPhone1()));
		put(HOURS_OF_OPERATION, regCustomer.getCustomerRegistrationLicenseDetail().getHoursOfOperation());
		put(DASHBOARD_LINK, configurationService.getConfiguration().getString("admin.dashboard"));
		final PageTemplateModel masterTemplate = emailPageModel.getMasterTemplate();
		final List<ContentSlotForTemplateModel> templateSlots = masterTemplate.getContentSlots();
		if (CollectionUtils.isNotEmpty(templateSlots))
		{
			for (final ContentSlotForTemplateModel contentSlotForTemplateModel : templateSlots)
			{
				if ((contentSlotForTemplateModel.getPosition().equalsIgnoreCase("emailFooterSlotName")))
				{
					put(FOOTER_COMPONENTS, contentSlotForTemplateModel.getContentSlot() != null
							? contentSlotForTemplateModel.getContentSlot().getCmsComponents() : new ArrayList<CMSLinkComponentModel>());
				}
			}
		}

	}

	private String dateFormat(final Date date)
	{
		if (null != date)
		{
			final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
			return simpleDateFormat.format(date);
		}
		return null;
	}

	private String phoneNumberFormat(final String phone)
	{
		return phone.replaceAll("[^A-Za-z0-9]", "");
	}

	@Override
	protected BaseSiteModel getSite(final IcommerceCustomerRegEmailProcessModel businessProcessModel)
	{
		return businessProcessModel.getSite();
	}

	@Override
	protected CustomerModel getCustomer(final IcommerceCustomerRegEmailProcessModel businessProcessModel)
	{
		return null;
	}

	@Override
	protected LanguageModel getEmailLanguage(final IcommerceCustomerRegEmailProcessModel businessProcessModel)
	{
		return businessProcessModel.getLanguage();
	}

	public String getLoginUrl() throws UnsupportedEncodingException
	{
		return getSiteBaseUrlResolutionService().getWebsiteUrlForSite(getBaseSite(), getUrlEncodingAttributes(), true, "/login");
	}

}
