/**
 *
 */
package com.icommerce.facades.process.email.context;

import de.hybris.platform.acceleratorservices.model.cms2.pages.EmailPageModel;
import de.hybris.platform.acceleratorservices.process.email.context.AbstractEmailContext;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.cms2.model.contents.components.CMSLinkComponentModel;
import de.hybris.platform.cms2.model.pages.PageTemplateModel;
import de.hybris.platform.cms2.model.relations.ContentSlotForTemplateModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.user.CustomerModel;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.icommerce.core.model.IcommerceCustomerRegistrationModel;
import com.icommerceb2b.core.model.IcommerceCustomerRegEmailProcessModel;


/**
 * Lscareb2bRegistrationEmailContext
 *
 */
public class IcommerceRegistrationEmailContext extends AbstractEmailContext<IcommerceCustomerRegEmailProcessModel>
{
	private IcommerceCustomerRegistrationModel regCustomer;
	public static final String FOOTER_COMPONENTS = "footerComponents";

	/**
	 * @return the regCustomer
	 */
	public IcommerceCustomerRegistrationModel getRegCustomer()
	{
		return regCustomer;
	}

	/**
	 * @param regCustomer
	 *           the regCustomer to set
	 */
	public void setRegCustomer(final IcommerceCustomerRegistrationModel regCustomer)
	{
		this.regCustomer = regCustomer;
	}

	@Override
	public void init(final IcommerceCustomerRegEmailProcessModel lscareB2BCustomerRegEmailProcess,
			final EmailPageModel emailPageModel)
	{
		super.init(lscareB2BCustomerRegEmailProcess, emailPageModel);
		regCustomer = lscareB2BCustomerRegEmailProcess.getRegisteredUser();

		put(DISPLAY_NAME, regCustomer.getFirstName());
		put(EMAIL, regCustomer.getEmailId());
		final PageTemplateModel masterTemplate = emailPageModel.getMasterTemplate();
		final List<ContentSlotForTemplateModel> templateSlots = masterTemplate.getContentSlots();
		if (CollectionUtils.isNotEmpty(templateSlots))
		{
			for (final ContentSlotForTemplateModel contentSlotForTemplateModel : templateSlots)
			{
				if ((contentSlotForTemplateModel.getPosition().equalsIgnoreCase("emailFooterSlotName")))
				{
					put(FOOTER_COMPONENTS, contentSlotForTemplateModel.getContentSlot() != null
							? contentSlotForTemplateModel.getContentSlot().getCmsComponents() : new ArrayList<CMSLinkComponentModel>());
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.hybris.platform.acceleratorservices.process.email.context.AbstractEmailContext#getSite(de.hybris.platform.
	 * processengine.model.BusinessProcessModel)
	 */
	@Override
	protected BaseSiteModel getSite(final IcommerceCustomerRegEmailProcessModel businessProcessModel)
	{
		// YTODO Auto-generated method stub
		return businessProcessModel.getSite();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * de.hybris.platform.acceleratorservices.process.email.context.AbstractEmailContext#getCustomer(de.hybris.platform.
	 * processengine.model.BusinessProcessModel)
	 */
	@Override
	protected CustomerModel getCustomer(final IcommerceCustomerRegEmailProcessModel businessProcessModel)
	{
		// YTODO Auto-generated method stub
		return null;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see de.hybris.platform.acceleratorservices.process.email.context.AbstractEmailContext#getEmailLanguage(de.hybris.
	 * platform.processengine.model.BusinessProcessModel)
	 */
	@Override
	protected LanguageModel getEmailLanguage(final IcommerceCustomerRegEmailProcessModel businessProcessModel)
	{
		// YTODO Auto-generated method stub
		return businessProcessModel.getLanguage();
	}

	public String getLoginUrl() throws UnsupportedEncodingException
	{
		return getSiteBaseUrlResolutionService().getWebsiteUrlForSite(getBaseSite(), getUrlEncodingAttributes(), true, "/login");
	}

}
