/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jul 23, 2018 4:50:57 PM                     ---
 * ----------------------------------------------------------------
 */
package com.icommerce.initialdata.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedIcommerceInitialDataConstants
{
	public static final String EXTENSIONNAME = "icommerceinitialdata";
	
	protected GeneratedIcommerceInitialDataConstants()
	{
		// private constructor
	}
	
	
}
