/**
 *
 */
package com.icommerce.storefront.controllers.pages;


import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractRegisterPageController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.AbstractPageModel;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.store.BaseStoreModel;
import de.hybris.platform.store.services.BaseStoreService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.icommerce.core.exceptions.IcommerceBusinessException;
import com.icommerce.core.services.IcommerceCaptchaService;
import com.icommerce.facades.customer.CustomerRegistrationFacade;
import com.icommerce.facades.cutomer.data.IcommerceCustomerRegistrationData;
import com.icommerce.storefront.controllers.ControllerConstants;
import com.icommerce.storefront.forms.CustomerRegisterForm;
import com.icommerce.storefront.forms.utill.PopulateLscareFormToLscareDataUtil;




/**
 * Register Controller for Lscare. Handles register for create account flow.
 */
@Controller
@Scope("tenant")
@RequestMapping(value = "/registercustomer")
public class IcommerceCustomerRegisterPageController extends AbstractRegisterPageController
{

	private static final Logger LOGGER = Logger.getLogger(IcommerceCustomerRegisterPageController.class);

	private HttpSessionRequestCache httpSessionRequestCache;

	private static final String REGISTRATION_CMS_PAGE = "registrationpage";
	private static final String HOME_CMS_PAGE = "homepage";

	private static final String REG_SUCCESS_PAGE = "registration-success";


	@Autowired
	private CustomerRegistrationFacade customerRegistrationFacade;

	@Resource
	private IcommerceCaptchaService lscareCaptchaService;

	@Resource
	private ConfigurationService configurationService;

	@Resource(name = "baseStoreService")
	private BaseStoreService baseStoreService;

	@Autowired
	UserService userService;

	@Override
	protected AbstractPageModel getCmsPage() throws CMSItemNotFoundException
	{
		return getContentPageForLabelOrId("register");
	}

	@Override
	protected String getSuccessRedirect(final HttpServletRequest request, final HttpServletResponse response)
	{
		if (httpSessionRequestCache.getRequest(request, response) != null)
		{
			return httpSessionRequestCache.getRequest(request, response).getRedirectUrl();
		}
		return "/";
	}

	@Override
	protected String getView()
	{
		return ControllerConstants.Views.Pages.Account.AccountRegisterPage;
	}

	@Resource(name = "httpSessionRequestCache")
	public void setHttpSessionRequestCache(final HttpSessionRequestCache accHttpSessionRequestCache)
	{
		this.httpSessionRequestCache = accHttpSessionRequestCache;
	}


	/**
	 * @param form
	 * @param model
	 * @throws CMSItemNotFoundException
	 *
	 *            Method to display Lscare Account Registration Page
	 *
	 */

	@RequestMapping(method = RequestMethod.GET)
	public String register(final CustomerRegisterForm form, final Model model, final BindingResult bindingResult,
			final HttpServletRequest request) throws CMSItemNotFoundException
	{
		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("LscareRegisterPageController:register() ");
		}
		if (!userService.isAnonymousUser(userService.getCurrentUser()))
		{
			return REDIRECT_PREFIX + "/";
		}
		return goToRegisterPage(model);
	}

	/**
	 * checkEmail method to verify weather the customer is exists or not
	 *
	 */
	@RequestMapping(value = "/check-email", method = RequestMethod.POST)
	@ResponseBody
	public String checkEmail(@RequestParam(value = "email", required = false) final String email) throws Exception
	{
		String status = null;
		if (null != email && customerRegistrationFacade.isCustomerExist(email))
		{
			status = "This email is already registered, Please try with other email..!!";
		}
		return status;
	}


	/**
	 * @param form
	 * @param model
	 * @throws CMSItemNotFoundException
	 *
	 *            This method performs enrollment of customer
	 *
	 */
	@RequestMapping(value = "/create-account", method = RequestMethod.POST)
	public String customerRegister(@ModelAttribute("registerForm") final CustomerRegisterForm form,
			final BindingResult bindingResult, final Model model, final HttpServletRequest request,
			final HttpServletResponse response, final RedirectAttributes redirectModel) throws CMSItemNotFoundException
	{

		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("LscareRegisterPageController:customerRegister() starts");
		}

		if (null != request.getParameter("licenseDetailsForm.isGovFederalOrg"))
		{
			form.getLicenseDetailsForm().setGovFederalOrg(true);
		}

		final PopulateLscareFormToLscareDataUtil populateLscareFormToLscareDataUtil = new PopulateLscareFormToLscareDataUtil();
		final IcommerceCustomerRegistrationData lscareB2BCustomerRegistrationData = populateLscareFormToLscareDataUtil
				.populateCustRegiFormToData(form);

		//captcha validation
		if (isCaptchaEnabledForCurrentStore()
				&& !lscareCaptchaService.validateCaptchaResponse(request.getParameter("g-recaptcha-response")))
		{
			LOGGER.error(configurationService.getConfiguration().getString("captchaErrorMessage", "Captcha validation failed"));
			GlobalMessages.addErrorMessage(model,
					configurationService.getConfiguration().getString("captchaErrorMessage", "Captcha validation failed"));
			return goToRegisterPage(model);
		}
		else
		{
			//user creation flow
			try
			{
				customerRegistrationFacade.registerCustomerRequest(lscareB2BCustomerRegistrationData);
			}
			catch (final IcommerceBusinessException e)
			{
				model.addAttribute("emailalradyExists", e.getMessage());
				GlobalMessages.addErrorMessage(model, e.getMessage());
				return goToRegisterPage(model);
			}
			catch (final Exception e)
			{
				LOGGER.error("Exception while customer Registration :" + e.getMessage());
				GlobalMessages.addErrorMessage(model, "some exception occured during customer Registration, Please try again..!!");
				return goToRegisterPage(model);
			}
		}

		storeCmsPageInModel(model, getContentPageForLabelOrId(REG_SUCCESS_PAGE));
		setUpMetaDataForContentPage(model, getContentPageForLabelOrId(REG_SUCCESS_PAGE));
		LOGGER.debug("customerRegister of Controller Ends ::");
		return ControllerConstants.Views.Pages.Registration.RegistrationSuccessPage;
	}

	/**
	 * @param model
	 * @param registerForm
	 * @return
	 * @throws CMSItemNotFoundException
	 */
	private String goToRegisterPage(final Model model) throws CMSItemNotFoundException
	{
		final CustomerRegisterForm registerForm = new CustomerRegisterForm();
		model.addAttribute("registerForm", registerForm);
		storeCmsPageInModel(model, getAccountRegisterPage());
		setUpMetaDataForContentPage(model, (ContentPageModel) getAccountRegisterPage());
		return ControllerConstants.Views.Pages.Registration.RegistrationPage;
	}

	/**
	 * This method is used to validate if captcha has been enabled for currect store.
	 *
	 * @return boolean
	 */
	protected boolean isCaptchaEnabledForCurrentStore()
	{
		final BaseStoreModel currentBaseStore = baseStoreService.getCurrentBaseStore();
		return currentBaseStore != null && Boolean.TRUE.equals(currentBaseStore.getCaptchaCheckEnabled());
	}

	/**
	 * @return the customerRegistrationFacade
	 */
	public CustomerRegistrationFacade getCustomerRegistrationFacade()
	{
		return customerRegistrationFacade;
	}

	/**
	 * @param customerRegistrationFacade
	 *           the customerRegistrationFacade to set
	 */
	public void setCustomerRegistrationFacade(final CustomerRegistrationFacade customerRegistrationFacade)
	{
		this.customerRegistrationFacade = customerRegistrationFacade;
	}

	protected AbstractPageModel getAccountRegisterPage() throws CMSItemNotFoundException
	{
		return getContentPageForLabelOrId(REGISTRATION_CMS_PAGE);
	}

}
