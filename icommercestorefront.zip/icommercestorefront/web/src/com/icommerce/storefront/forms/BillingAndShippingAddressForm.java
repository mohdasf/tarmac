
package com.icommerce.storefront.forms;

/**
 * BillingAndShippingAddress are using Customer Registration process
 *
 */
public class BillingAndShippingAddressForm
{

	private boolean sameAsShipAddr;
	private String Line1;
	private String Line2;
	private String postalCode;
	private String city;
	private String billingState;
	private String billingOrgName;
	private String phone;


	/**
	 * @return the line1
	 */
	public String getLine1()
	{
		return Line1;
	}

	/**
	 * @param line1
	 *           the line1 to set
	 */
	public void setLine1(final String line1)
	{
		Line1 = line1;
	}

	/**
	 * @return the line2
	 */
	public String getLine2()
	{
		return Line2;
	}

	/**
	 * @param line2
	 *           the line2 to set
	 */
	public void setLine2(final String line2)
	{
		Line2 = line2;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode()
	{
		return postalCode;
	}

	/**
	 * @param postalCode
	 *           the postalCode to set
	 */
	public void setPostalCode(final String postalCode)
	{
		this.postalCode = postalCode;
	}

	/**
	 * @return the city
	 */
	public String getCity()
	{
		return city;
	}

	/**
	 * @param city
	 *           the city to set
	 */
	public void setCity(final String city)
	{
		this.city = city;
	}

	/**
	 * @return the billingOrgName
	 */
	public String getBillingOrgName()
	{
		return billingOrgName;
	}

	/**
	 * @param billingOrgName
	 *           the billingOrgName to set
	 */
	public void setBillingOrgName(final String billingOrgName)
	{
		this.billingOrgName = billingOrgName;
	}

	/**
	 * @return the billingState
	 */
	public String getBillingState()
	{
		return billingState;
	}

	/**
	 * @param billingState
	 *           the billingState to set
	 */
	public void setBillingState(final String billingState)
	{
		this.billingState = billingState;
	}

	/**
	 * @return the phone
	 */
	public String getPhone()
	{
		return phone;
	}

	/**
	 * @param phone
	 *           the phone to set
	 */
	public void setPhone(final String phone)
	{
		this.phone = phone;
	}

	/**
	 * @return the sameAsShipAddr
	 */
	public boolean isSameAsShipAddr()
	{
		return sameAsShipAddr;
	}

	/**
	 * @param sameAsShipAddr
	 *           the sameAsShipAddr to set
	 */
	public void setSameAsShipAddr(final boolean sameAsShipAddr)
	{
		this.sameAsShipAddr = sameAsShipAddr;
	}

}
