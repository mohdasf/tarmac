/**
 *
 */
package com.icommerce.storefront.forms;

import de.hybris.platform.acceleratorstorefrontcommons.forms.RegisterForm;


/**
 * @author nesingh
 *
 */
public class CustomerRegisterForm extends RegisterForm
{

	private String confEmail;
	private String position;
	private String role;

	private boolean optNotify;
	private String orgName;

	private LicenseDetailsForm licenseDetailsForm;
	private BillingAndShippingAddressForm billAndShippAddressForm;

	/**
	 * @return the confEmail
	 */
	public String getConfEmail()
	{
		return confEmail;
	}

	/**
	 * @param confEmail
	 *           the confEmail to set
	 */
	public void setConfEmail(final String confEmail)
	{
		this.confEmail = confEmail;
	}

	/**
	 * @return the position
	 */
	public String getPosition()
	{
		return position;
	}

	/**
	 * @param position
	 *           the position to set
	 */
	public void setPosition(final String position)
	{
		this.position = position;
	}


	/**
	 * @return the licenseDetailsForm
	 */
	public LicenseDetailsForm getLicenseDetailsForm()
	{
		return licenseDetailsForm;
	}

	/**
	 * @param licenseDetailsForm
	 *           the licenseDetailsForm to set
	 */
	public void setLicenseDetailsForm(final LicenseDetailsForm licenseDetailsForm)
	{
		this.licenseDetailsForm = licenseDetailsForm;
	}

	/**
	 * @return the billAndShippAddressForm
	 */
	public BillingAndShippingAddressForm getBillAndShippAddressForm()
	{
		return billAndShippAddressForm;
	}

	/**
	 * @param billAndShippAddressForm
	 *           the billAndShippAddressForm to set
	 */
	public void setBillAndShippAddressForm(final BillingAndShippingAddressForm billAndShippAddressForm)
	{
		this.billAndShippAddressForm = billAndShippAddressForm;
	}

	/**
	 * @return the orgName
	 */
	public String getOrgName()
	{
		return orgName;
	}

	/**
	 * @param orgName
	 *           the orgName to set
	 */
	public void setOrgName(final String orgName)
	{
		this.orgName = orgName;
	}

	/**
	 * @return the optNotify
	 */
	public boolean isOptNotify()
	{
		return optNotify;
	}

	/**
	 * @param optNotify
	 *           the optNotify to set
	 */
	public void setOptNotify(final boolean optNotify)
	{
		this.optNotify = optNotify;
	}

	/**
	 * @return the role
	 */
	public String getRole()
	{
		return role;
	}

	/**
	 * @param role
	 *           the role to set
	 */
	public void setRole(final String role)
	{
		this.role = role;
	}

}
