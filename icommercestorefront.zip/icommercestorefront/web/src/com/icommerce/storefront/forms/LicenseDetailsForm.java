
package com.icommerce.storefront.forms;

/**
 * LicenseDetailsForm are using Customer Registration process
 *
 */


public class LicenseDetailsForm
{
	private boolean isGovFederalOrg;
	private String licenseName;
	private String licenseNum;
	private String licenseExpiryDate;
	private String licAddressLine1;
	private String stateIssuingLicence;
	private String shippingAddressLine1;
	private String licensePostalCode;
	private String licenseCity;
	private String shippingState;
	private String shippingOrgName;
	private String phone;
	private String operationsHours;


	/**
	 * @return the licenseName
	 */
	public String getLicenseName()
	{
		return licenseName;
	}

	/**
	 * @param licenseName
	 *           the licenseName to set
	 */
	public void setLicenseName(final String licenseName)
	{
		this.licenseName = licenseName;
	}

	/**
	 * @return the licenseNum
	 */
	public String getLicenseNum()
	{
		return licenseNum;
	}

	/**
	 * @param licenseNum
	 *           the licenseNum to set
	 */
	public void setLicenseNum(final String licenseNum)
	{
		this.licenseNum = licenseNum;
	}

	/**
	 * @return the licensePostalCode
	 */
	public String getLicensePostalCode()
	{
		return licensePostalCode;
	}

	/**
	 * @param licensePostalCode
	 *           the licensePostalCode to set
	 */
	public void setLicensePostalCode(final String licensePostalCode)
	{
		this.licensePostalCode = licensePostalCode;
	}

	/**
	 * @return the licenseCity
	 */
	public String getLicenseCity()
	{
		return licenseCity;
	}

	/**
	 * @param licenseCity
	 *           the licenseCity to set
	 */
	public void setLicenseCity(final String licenseCity)
	{
		this.licenseCity = licenseCity;
	}

	/**
	 * @return the shippingOrgName
	 */
	public String getShippingOrgName()
	{
		return shippingOrgName;
	}

	/**
	 * @param shippingOrgName
	 *           the shippingOrgName to set
	 */
	public void setShippingOrgName(final String shippingOrgName)
	{
		this.shippingOrgName = shippingOrgName;
	}

	/**
	 * @return the phone
	 */
	public String getPhone()
	{
		return phone;
	}

	/**
	 * @param phone
	 *           the phone to set
	 */
	public void setPhone(final String phone)
	{
		this.phone = phone;
	}

	/**
	 * @return the operationsHours
	 */
	public String getOperationsHours()
	{
		return operationsHours;
	}

	/**
	 * @param operationsHours
	 *           the operationsHours to set
	 */
	public void setOperationsHours(final String operationsHours)
	{
		this.operationsHours = operationsHours;
	}

	/**
	 * @return the isGovFederalOrg
	 */
	public boolean isGovFederalOrg()
	{
		return isGovFederalOrg;
	}

	/**
	 * @param isGovFederalOrg
	 *           the isGovFederalOrg to set
	 */
	public void setGovFederalOrg(final boolean isGovFederalOrg)
	{
		this.isGovFederalOrg = isGovFederalOrg;
	}



	/**
	 * @return the shippingState
	 */
	public String getShippingState()
	{
		return shippingState;
	}

	/**
	 * @param shippingState
	 *           the shippingState to set
	 */
	public void setShippingState(final String shippingState)
	{
		this.shippingState = shippingState;
	}

	/**
	 * @return the licenseExpiryDate
	 */
	public String getLicenseExpiryDate()
	{
		return licenseExpiryDate;
	}

	/**
	 * @param licenseExpiryDate
	 *           the licenseExpiryDate to set
	 */
	public void setLicenseExpiryDate(final String licenseExpiryDate)
	{
		this.licenseExpiryDate = licenseExpiryDate;
	}

	/**
	 * @return the licAddressLine1
	 */
	public String getLicAddressLine1()
	{
		return licAddressLine1;
	}

	/**
	 * @param licAddressLine1
	 *           the licAddressLine1 to set
	 */
	public void setLicAddressLine1(final String licAddressLine1)
	{
		this.licAddressLine1 = licAddressLine1;
	}

	/**
	 * @return the stateIssuingLicence
	 */
	public String getStateIssuingLicence()
	{
		return stateIssuingLicence;
	}

	/**
	 * @param stateIssuingLicence
	 *           the stateIssuingLicence to set
	 */
	public void setStateIssuingLicence(final String stateIssuingLicence)
	{
		this.stateIssuingLicence = stateIssuingLicence;
	}

	/**
	 * @return the shippingAddressLine1
	 */
	public String getShippingAddressLine1()
	{
		return shippingAddressLine1;
	}

	/**
	 * @param shippingAddressLine1
	 *           the shippingAddressLine1 to set
	 */
	public void setShippingAddressLine1(final String shippingAddressLine1)
	{
		this.shippingAddressLine1 = shippingAddressLine1;
	}

}
