/**
 *
 */
package com.icommerce.storefront.forms.utill;



import org.apache.log4j.Logger;

import com.icommerce.facades.cutomer.data.CustomerRegistrationAddressData;
import com.icommerce.facades.cutomer.data.CustomerRegistrationLicenseDetailData;
import com.icommerce.facades.cutomer.data.IcommerceCustomerRegistrationData;
import com.icommerce.storefront.forms.CustomerRegisterForm;



/**
 *
 * PopulateLscareFormToLscareDataUtil to populate form class data to Data class
 */

public class PopulateLscareFormToLscareDataUtil
{

	private static final Logger LOGGER = Logger.getLogger(PopulateLscareFormToLscareDataUtil.class);


	public IcommerceCustomerRegistrationData populateCustRegiFormToData(final CustomerRegisterForm form)
	{
		IcommerceCustomerRegistrationData seqData = null;

		if (form != null)
		{
			seqData = new IcommerceCustomerRegistrationData();
			if (form.getFirstName() != null)
			{
				seqData.setFirstName(form.getFirstName());
			}
			if (form.getLastName() != null)
			{
				seqData.setLastName(form.getLastName());
			}
			if (form.getEmail() != null)
			{
				seqData.setEmailId(form.getEmail().toLowerCase());
			}

			if (form.getPosition() != null)
			{
				seqData.setPosition(form.getPosition());
			}


			if (form.getRole() != null)
			{
				seqData.setRole(form.getRole());
			}



			if (form.getOrgName() != null)
			{
				seqData.setOrganizationName(form.getOrgName());
			}

			seqData.setOptNotify(form.isOptNotify());

			/* Shipping address details */

			if (form.getLicenseDetailsForm() != null)
			{
				final CustomerRegistrationLicenseDetailData licenseDetailsData = new CustomerRegistrationLicenseDetailData();

				licenseDetailsData.setIsFederalOrganization(form.getLicenseDetailsForm().isGovFederalOrg());

				if (!form.getLicenseDetailsForm().isGovFederalOrg())
				{
					if (form.getLicenseDetailsForm().getLicenseName() != null)
					{
						licenseDetailsData.setLicenseName(form.getLicenseDetailsForm().getLicenseName());
					}
					if (form.getLicenseDetailsForm().getLicenseNum() != null)
					{
						licenseDetailsData.setLicenseStateNumber(form.getLicenseDetailsForm().getLicenseNum());
					}
					if (form.getLicenseDetailsForm().getLicenseExpiryDate() != null)
					{
						licenseDetailsData.setLicexpiryDate(form.getLicenseDetailsForm().getLicenseExpiryDate());
					}
					if (form.getLicenseDetailsForm().getLicAddressLine1() != null)
					{
						licenseDetailsData.setLicenceAddressLine1(form.getLicenseDetailsForm().getLicAddressLine1());
					}
					if (form.getLicenseDetailsForm().getStateIssuingLicence() != null)
					{
						licenseDetailsData.setStateIssuingLicence(form.getLicenseDetailsForm().getStateIssuingLicence());
					}
				}

				if (form.getLicenseDetailsForm().getShippingOrgName() != null)
				{
					licenseDetailsData.setOrganizationName(form.getLicenseDetailsForm().getShippingOrgName());
				}

				final CustomerRegistrationAddressData shippingAddress = new CustomerRegistrationAddressData();

				if (form.getLicenseDetailsForm().getShippingAddressLine1() != null)
				{
					shippingAddress.setLine1(form.getLicenseDetailsForm().getShippingAddressLine1());
				}
				if (form.getLicenseDetailsForm().getLicensePostalCode() != null)
				{
					shippingAddress.setPostalCode(form.getLicenseDetailsForm().getLicensePostalCode());
				}

				if (form.getLicenseDetailsForm().getShippingState() != null)
				{
					shippingAddress.setState(form.getLicenseDetailsForm().getShippingState());
				}
				if (form.getLicenseDetailsForm().getLicenseCity() != null)
				{
					shippingAddress.setTown(form.getLicenseDetailsForm().getLicenseCity());
				}
				if (form.getLicenseDetailsForm().getPhone() != null)
				{
					shippingAddress.setPhone(form.getLicenseDetailsForm().getPhone());
				}
				if (form.getLicenseDetailsForm().getOperationsHours() != null)
				{
					licenseDetailsData.setHoursOfOperation(form.getLicenseDetailsForm().getOperationsHours());
				}
				licenseDetailsData.setShippingAddress(shippingAddress);
				seqData.setLicenseDetails(licenseDetailsData);
			}

			/* Shipping address details */

			if (form.getBillAndShippAddressForm() != null)
			{
				final CustomerRegistrationAddressData billingAddressData = new CustomerRegistrationAddressData();

				billingAddressData.setIsSameAsShippingAddress(form.getBillAndShippAddressForm().isSameAsShipAddr());

				if (form.getBillAndShippAddressForm().isSameAsShipAddr())
				{
					if (form.getLicenseDetailsForm().getShippingOrgName() != null)
					{
						billingAddressData.setOrganizationName(form.getLicenseDetailsForm().getShippingOrgName());
					}

					if (form.getLicenseDetailsForm().getShippingAddressLine1() != null)
					{
						billingAddressData.setLine1(form.getLicenseDetailsForm().getShippingAddressLine1());
					}
					if (form.getLicenseDetailsForm().getShippingState() != null)
					{
						billingAddressData.setState(form.getLicenseDetailsForm().getShippingState());
					}
					if (form.getLicenseDetailsForm().getLicenseCity() != null)
					{
						billingAddressData.setTown(form.getLicenseDetailsForm().getLicenseCity());
					}
					if (form.getLicenseDetailsForm().getLicensePostalCode() != null)
					{
						billingAddressData.setPostalCode(form.getLicenseDetailsForm().getLicensePostalCode());
					}
					if (form.getLicenseDetailsForm().getPhone() != null)
					{
						billingAddressData.setPhone(form.getLicenseDetailsForm().getPhone());
					}
				}
				else
				{
					if (form.getBillAndShippAddressForm().getBillingOrgName() != null)
					{
						billingAddressData.setOrganizationName(form.getBillAndShippAddressForm().getBillingOrgName());
					}
					if (form.getBillAndShippAddressForm().getLine1() != null)
					{
						billingAddressData.setLine1(form.getBillAndShippAddressForm().getLine1());
					}
					if (form.getBillAndShippAddressForm().getLine2() != null)
					{
						billingAddressData.setLine2(form.getBillAndShippAddressForm().getLine2());
					}
					if (form.getBillAndShippAddressForm().getCity() != null)
					{
						billingAddressData.setTown(form.getBillAndShippAddressForm().getCity());
					}
					if (form.getBillAndShippAddressForm().getBillingState() != null)
					{
						billingAddressData.setState(form.getBillAndShippAddressForm().getBillingState());
					}

					if (form.getBillAndShippAddressForm().getPostalCode() != null)
					{
						billingAddressData.setPostalCode(form.getBillAndShippAddressForm().getPostalCode());
					}
					if (form.getBillAndShippAddressForm().getPhone() != null)
					{
						billingAddressData.setPhone(form.getBillAndShippAddressForm().getPhone());
					}
				}
				seqData.setBillingAddress(billingAddressData);
			}

		}
		return seqData;
	}
}

