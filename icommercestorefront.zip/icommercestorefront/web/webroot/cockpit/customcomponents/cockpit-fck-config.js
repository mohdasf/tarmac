FCKConfig.ToolbarSets["Default"] = [
['Source','Preview','ShowBlocks','Print', 'Undo','Redo','-',
 //'SpellCheck',   //uncomment for spellchecker icon
'-','Find','Replace','-','SelectAll','RemoveFormat','-','Subscript','Superscript','-','Outdent','Indent','Blockquote'],
'/',
['Bold','Italic','Underline','StrikeThrough','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyFull','-','OrderedList','UnorderedList','-','Link','Unlink','Anchor','-','Table','Rule','SpecialChar','PageBreak'],
'/',
['FontFormat','FontName','FontSize']
] ;

FCKConfig.SkinPath = FCKConfig.BasePath + 'skins/silver/' ;
